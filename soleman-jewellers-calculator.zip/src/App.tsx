import React from "react";
import { Header } from "./components/Header";
import { BuySellTab } from "./components/BuySellTab";
import { OldToNewTab } from "./components/OldToNewTab";
import { ExchangeTabs } from "./components/ExchangeTabs";
import { LoanTab } from "./components/LoanTab";
import { HistoryTab } from "./components/HistoryTab";
import { InvoiceModal } from "./components/InvoiceModal";
import { locales } from "./locales";
import { PriceSettings, BillItem, LoanAccount } from "./types";
import { Calculator, Recycle, ArrowRightLeft, Coins, Banknote, History, ChevronUp, ChevronDown } from "lucide-react";

// Accent presets color palettes mapping
const THEME_PALETTES = [
  { // Sky Default
    bodyClass: "bg-radial from-slate-50 to-sky-100/50 text-slate-900 border-sky-500",
    glow1: "rgba(14, 165, 233, 0.12)",
    glow2: "rgba(59, 130, 246, 0.10)",
    activeTab: "bg-sky-500 text-white shadow-sky-500/20",
    ringClass: "focus:ring-sky-500/50"
  },
  { // Emerald
    bodyClass: "bg-radial from-slate-50 to-emerald-100/40 text-slate-900 border-emerald-500",
    glow1: "rgba(16, 185, 129, 0.12)",
    glow2: "rgba(52, 211, 153, 0.10)",
    activeTab: "bg-emerald-500 text-white shadow-emerald-500/20",
    ringClass: "focus:ring-emerald-500/50"
  },
  { // Royal Violet
    bodyClass: "bg-radial from-slate-50 to-violet-100/40 text-slate-900 border-violet-500",
    glow1: "rgba(139, 92, 246, 0.12)",
    glow2: "rgba(167, 139, 250, 0.12)",
    activeTabClass: "bg-purple-500 text-white shadow-md shadow-purple-500/20"
  },
  { // Rose Sunset
    bodyClass: "bg-radial-ellipse from-rose-50/20 via-slate-50 to-slate-100",
    borderColor: "border-rose-500"
  }
];

export default function App() {
  const [lang, setLang] = React.useState<"bn" | "en">("bn");
  const [activeTab, setActiveFilter] = React.useState<string>("profit");
  
  // Settle States Backup sync Indicators
  const [syncState, setSyncState] = React.useState<"idle" | "saving" | "saved" | "error">("idle");
  const [themeIdx, setThemeIdx] = React.useState(0);

  // App data list states
  const [prices, setPrices] = React.useState<PriceSettings>({
    goldPrice: 140000,
    oldGoldPriceGeneral: 138000,
    oldGoldPriceNakmachi: 138000,
    newSilverPrice: 2050,
    oldSilverPrice: 1700
  });

  const [bills, setBills] = React.useState<BillItem[]>([]);
  const [loans, setLoans] = React.useState<LoanAccount[]>([]);

  // Active Billing Preview Modal State
  const [activePreviewItem, setActivePreviewItem] = React.useState<any | null>(null);
  const [activePreviewType, setActivePreviewType] = React.useState<"bill" | "loan" | null>(null);
  const [previewLoanAccount, setPreviewLoanAccount] = React.useState<LoanAccount | null>(null);

  const t = React.useCallback((key: string): string => {
    return locales[lang][key] || key;
  }, [lang]);

  // Theme presettings rotation
  const randomizeTheme = () => {
    setThemeIdx((prev) => (prev + 1) % 4);
  };

  const themeClasses = [
    "from-slate-50 via-sky-50/25 to-sky-100/10",
    "from-slate-50 via-emerald-50/25 to-emerald-100/5",
    "from-slate-50 via-purple-50/25 to-purple-100/5",
    "from-slate-50 via-rose-50/25 to-rose-100/5"
  ];

  // API - Get Prices and Backup synchronizations on Mount
  const fetchPricesAndSync = React.useCallback(() => {
    setSyncState("saving");
    
    // Fetch stored prices
    fetch("/api/prices")
      .then((res) => {
        if (!res.ok) throw new Error("Price fetch failed");
        return res.json();
      })
      .then((data) => {
        if (data.goldPrice) {
          setPrices(data);
        }
      })
      .catch((err) => console.warn("Prices lookup failed, running offline/default:", err));

    // Fetch synchronized backups (local file memory)
    fetch("/api/sync")
      .then((res) => {
        if (!res.ok) throw new Error("Sync load failed");
        return res.json();
      })
      .then((data) => {
        if (data.bills) {
          const loadedBills = JSON.parse(data.bills);
          setBills(loadedBills);
          localStorage.setItem("solemanJewellersBills", data.bills);
        }
        if (data.loans) {
          const loadedLoans = JSON.parse(data.loans);
          setLoans(loadedLoans);
          localStorage.setItem("soleman_loan_accounts", data.loans);
        }
        setSyncState("saved");
      })
      .catch((err) => {
        console.warn("Server sync backup unavailable (likely offline):", err);
        setSyncState("error");

        // Fallback strictly on localStorage values
        const localBills = localStorage.getItem("solemanJewellersBills");
        const localLoans = localStorage.getItem("soleman_loan_accounts");
        if (localBills) setBills(JSON.parse(localBills));
        if (localLoans) setLoans(JSON.parse(localLoans));
      });
  }, []);

  React.useEffect(() => {
    fetchPricesAndSync();
  }, [fetchPricesAndSync]);

  // Synchronize dynamic lists to server and localStorage on local changes (de-duplicated)
  const saveAndSyncStateOnServer = (newBills: BillItem[], newLoans: LoanAccount[]) => {
    setSyncState("saving");
    const billsStr = JSON.stringify(newBills);
    const loansStr = JSON.stringify(newLoans);

    localStorage.setItem("solemanJewellersBills", billsStr);
    localStorage.setItem("soleman_loan_accounts", loansStr);

    fetch("/api/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        bills: billsStr,
        loans: loansStr,
        settings: JSON.stringify(prices)
      })
    })
      .then((res) => {
        if (!res.ok) throw new Error("Sync POST negative");
        setSyncState("saved");
      })
      .catch((err) => {
        console.error("Backend synchronizations offset error. Saving locally:", err);
        setSyncState("error");
      });
  };

  // Actions - Save document
  const handleSaveBill = (bill: BillItem) => {
    const updated = [bill, ...bills];
    setBills(updated);
    saveAndSyncStateOnServer(updated, loans);
  };

  const handleDeleteBill = (id: number) => {
    const updated = bills.filter((b) => b.id !== id);
    setBills(updated);
    saveAndSyncStateOnServer(updated, loans);
  };

  // Actions - Save Loan Account Ledger
  const handleSaveLoanAccount = (account: Omit<LoanAccount, "lastUpdated">) => {
    const fullAccount: LoanAccount = {
      ...account,
      lastUpdated: new Date().toISOString()
    };
    const existsIdx = loans.findIndex((l) => l.id === account.id);
    let updated: LoanAccount[] = [];
    if (existsIdx !== -1) {
      updated = [...loans];
      updated[existsIdx] = fullAccount;
    } else {
      updated = [fullAccount, ...loans];
    }
    setLoans(updated);
    saveAndSyncStateOnServer(bills, updated);
  };

  const handleDeleteLoanAccount = (id: number) => {
    const updated = loans.filter((l) => l.id !== id);
    setLoans(updated);
    saveAndSyncStateOnServer(bills, updated);
  };

  const handlePrintLoanBill = (account: LoanAccount, calc: any) => {
    setActivePreviewItem({ account, calc });
    setActivePreviewType("loan");
  };

  return (
    <div className={`min-h-screen bg-linear-to-b ${themeClasses[themeIdx]} text-slate-800 transition-all duration-500 pb-16 font-sans relative`}>
      {/* Background visual blur indicators */}
      <div className="absolute top-1/4 left-1/10 w-96 h-96 rounded-full opacity-10 bg-sky-500 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 right-1/10 w-96 h-96 rounded-full opacity-10 bg-emerald-500 blur-3xl pointer-events-none" />

      {/* Corporate Header Section */}
      <Header
        lang={lang}
        setLang={setLang}
        prices={prices}
        fetchPrices={fetchPricesAndSync}
        syncState={syncState}
        randomizeTheme={randomizeTheme}
        t={t}
      />

      {/* Main Tab Routing Panels */}
      <main className="container max-w-5xl mx-auto px-4 mt-8">
        
        {/* Navigation Tabs Header */}
        <div className="flex bg-white/90 dark:bg-slate-900/90 backdrop-blur-md p-1.5 rounded-2xl shadow-lg border border-slate-200/50 dark:border-slate-800/80 mb-8 max-w-3xl mx-auto overflow-x-auto whitespace-nowrap scrollbar-thin">
          {[
            { id: "profit", label: t("tabBS"), icon: <Calculator className="w-4 h-4" /> },
            { id: "oldToNew", label: t("tabOTN"), icon: <Recycle className="w-4 h-4" /> },
            { id: "exchange", label: t("tabGoldEx"), icon: <ArrowRightLeft className="w-4 h-4" /> },
            { id: "silverExchange", label: t("tabSilverEx"), icon: <Coins className="w-4 h-4" /> },
            { id: "loan", label: t("tabLoan"), icon: <Banknote className="w-4 h-4" /> },
            { id: "history", label: t("tabHistory"), icon: <History className="w-4 h-4" /> }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id)}
                className={`flex-1 py-3 px-4 rounded-xl text-xs sm:text-xs font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  isActive
                    ? "bg-slate-800 dark:bg-sky-500 text-white shadow-lg shadow-slate-800/20 dark:shadow-sky-500/20 translate-y-[-1px]"
                    : "text-slate-500 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-100/55 dark:hover:bg-slate-800/50"
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Operational Calculation Panels screens */}
        <div className="relative animate-fadeIn min-h-[500px]">
          {activeTab === "profit" && (
            <BuySellTab
              lang={lang}
              prices={prices}
              gstPercent={3}
              onSaveBill={handleSaveBill}
              onPreviewBill={(item) => {
                setActivePreviewItem(item);
                setActivePreviewType("bill");
              }}
              t={t}
            />
          )}

          {activeTab === "oldToNew" && (
            <OldToNewTab
              lang={lang}
              prices={prices}
              gstPercent={3}
              onSaveBill={handleSaveBill}
              onPreviewBill={(item) => {
                setActivePreviewItem(item);
                setActivePreviewType("bill");
              }}
              t={t}
            />
          )}

          {activeTab === "exchange" && (
            <ExchangeTabs
              lang={lang}
              prices={prices}
              gstPercent={3}
              metal="gold"
              onSaveBill={handleSaveBill}
              onPreviewBill={(item) => {
                setActivePreviewItem(item);
                setActivePreviewType("bill");
              }}
              t={t}
            />
          )}

          {activeTab === "silverExchange" && (
            <ExchangeTabs
              lang={lang}
              prices={prices}
              gstPercent={3}
              metal="silver"
              onSaveBill={handleSaveBill}
              onPreviewBill={(item) => {
                setActivePreviewItem(item);
                setActivePreviewType("bill");
              }}
              t={t}
            />
          )}

          {activeTab === "loan" && (
            <LoanTab
              lang={lang}
              savedAccounts={loans}
              onSaveAccount={handleSaveLoanAccount}
              onDeleteAccount={handleDeleteLoanAccount}
              onPrintLoanBill={handlePrintLoanBill}
              t={t}
            />
          )}

          {activeTab === "history" && (
            <HistoryTab
              lang={lang}
              bills={bills}
              onDeleteBill={handleDeleteBill}
              onViewBillDetails={(item) => {
                setActivePreviewItem(item);
                setActivePreviewType("bill");
              }}
              t={t}
            />
          )}
        </div>
      </main>

      {/* Elegant layout footer */}
      <footer className="text-center py-8 mt-16 text-xs font-bold text-slate-400 select-none space-y-1">
        <p className="tracking-wide">{t("shopName")}</p>
        <p className="text-[10px] tracking-widest uppercase">{t("footerAddr")}</p>
        <p className="text-[9px] tracking-wider text-slate-400/60 font-mono">
          GSTIN: 19BMZPR4273E1Z9 | BIS Licence: HM/C-5191720314 | Designed in Node.js
        </p>
      </footer>

      {/* Integrated Live Billing overlay preview document frame */}
      {activePreviewItem && (
        <InvoiceModal
          lang={lang}
          activeItem={activePreviewItem}
          onClose={() => setActivePreviewItem(null)}
          t={t}
        />
      )}
    </div>
  );
}
