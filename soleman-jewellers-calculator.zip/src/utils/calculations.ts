import { BillItem, PriceSettings, ProfitBillDetails, OldToNewBillDetails, ExchangeBillDetails, LoanTransaction } from "../types";

export const GRAMS_TO_ANA_RATE = 16 / 11.664;

export function toFixedTrim(n: number, d = 2): number {
  return parseFloat(n.toFixed(d));
}

export function formatGramsToVoriAnaKuch(grams: number, lang: "en" | "bn"): string {
  if (!grams || grams <= 0) return "";
  const totalAna = grams * GRAMS_TO_ANA_RATE;
  
  let vori = Math.floor(totalAna / 16);
  let remainingAna = totalAna % 16;
  let ana = Math.floor(remainingAna);
  
  let fractionalAna = remainingAna - ana;
  let kuch = Math.round((fractionalAna * 100) / 16.6666667);

  if (kuch >= 6) {
    kuch -= 6;
    ana += 1;
  }
  if (ana >= 16) {
    ana -= 16;
    vori += 1;
  }

  const parts: string[] = [];
  if (lang === "en") {
    if (vori > 0) parts.push(`${vori} Vori`);
    if (ana > 0) parts.push(`${ana} Ana`);
    if (kuch > 0) parts.push(`${kuch} Rati/Kuch`);
    return parts.length > 0 ? `~ ${parts.join(" ")} (${totalAna.toFixed(3)} Ana)` : `0 Ana`;
  } else {
    if (vori > 0) parts.push(`${vori} ভরি`);
    if (ana > 0) parts.push(`${ana} আনা`);
    if (kuch > 0) parts.push(`${kuch} কুঁচ`);
    return parts.length > 0 ? `~ ${parts.join(" ")} (${totalAna.toFixed(3)} আনা)` : `০ আনা`;
  }
}

export function calculateProfitDetails(params: {
  basePrice24ct: number;
  weightGrams: number;
  quality: string;
  makingChargeType: "pergram" | "percent" | "fixed";
  makingChargeValue: number;
  gstPercent: number;
  customerName: string;
  customerPhone: string;
  qualityOptions: { [key: string]: string };
}): { details: ProfitBillDetails; total: number } {
  const {
    basePrice24ct,
    weightGrams,
    quality,
    makingChargeType,
    makingChargeValue,
    gstPercent,
    customerName,
    customerPhone,
    qualityOptions,
  } = params;

  let priceRatio = 0.92; // Default hm22k
  if (quality === "kdm") priceRatio = 0.85;
  else if (quality === "bengali") priceRatio = 0.75;
  else if (quality === "desi_bengali") priceRatio = 0.65;

  const totalGoldValue = toFixedTrim((basePrice24ct * priceRatio / 10) * weightGrams);
  
  let totalMakingCharge = 0;
  if (makingChargeType === "fixed") {
    totalMakingCharge = makingChargeValue;
  } else if (makingChargeType === "percent") {
    totalMakingCharge = (makingChargeValue / 100) * totalGoldValue;
  } else if (makingChargeType === "pergram") {
    totalMakingCharge = makingChargeValue * weightGrams;
  }
  totalMakingCharge = toFixedTrim(totalMakingCharge);

  const taxableAmount = totalGoldValue + totalMakingCharge;
  const gstAmount = toFixedTrim(taxableAmount * (gstPercent / 100));
  const total = toFixedTrim(taxableAmount + gstAmount);

  const details: ProfitBillDetails = {
    id: Date.now(),
    billType: "profit",
    date: new Date().toISOString(),
    customerName,
    customerPhone,
    basePrice24ct,
    weightGrams,
    quality,
    qualityName: qualityOptions[quality] || quality,
    makingChargeType,
    makingChargeValue,
    gstPercent,
    totalGoldValue,
    totalMakingCharge,
    gstAmount,
    total,
  };

  return { details, total };
}

export function calculateOldToNewDetails(params: {
  oldWeight: number;
  oldType: string;
  newWeight: number;
  newType: string;
  price24ct: number;
  makingType: "pergram" | "percent" | "fixed";
  makingValue: number;
  gstPercent: number;
  customerName: string;
  customerMobile: string;
}): OldToNewBillDetails {
  const {
    oldWeight,
    oldType,
    newWeight,
    newType,
    price24ct,
    makingType,
    makingValue,
    gstPercent,
    customerName,
    customerMobile,
  } = params;

  let pureGoldEq = 0;
  
  // Logical equivalency computations mapped from traditional workshop formulas
  if (oldType === "Licence" && newType === "kdm_850") { pureGoldEq = oldWeight * 85 / 85; }
  else if (oldType === "Licence" && newType === "bengali") { pureGoldEq = oldWeight * 85 / 75; }
  else if (oldType === "Licence" && newType === "desi_bengali") { pureGoldEq = oldWeight * 85 / 65; }
  else if (oldType === "kdm_850" && newType === "Licence") { pureGoldEq = oldWeight * 78 / 92; }
  else if (oldType === "kdm_850" && newType === "kdm_850") { pureGoldEq = oldWeight * 78 / 85; }
  else if (oldType === "kdm_850" && newType === "bengali") { pureGoldEq = oldWeight * 78 / 75; }
  else if (oldType === "kdm_850" && newType === "desi_bengali") { pureGoldEq = oldWeight * 78 / 65; }
  else if (oldType === "bengali" && newType === "kdm_850") { pureGoldEq = oldWeight * 65 / 85; }
  else if (oldType === "bengali" && newType === "desi_bengali") { pureGoldEq = oldWeight * 65 / 58; }
  else if (oldType === "bengali" && newType === "bengali") { pureGoldEq = oldWeight * 65 / 75; }
  else if (oldType === "desi_bengali" && newType === "Licence") { pureGoldEq = oldWeight * 58 / 92; }
  else if (oldType === "desi_bengali" && newType === "kdm_850") { pureGoldEq = oldWeight * 58 / 85; }
  else if (oldType === "desi_bengali" && newType === "bengali") { pureGoldEq = oldWeight * 58 / 75; }
  else if (oldType === "desi_bengali" && newType === "desi_bengali") { pureGoldEq = oldWeight * 58 / 65; }
  else {
    const oldPurityFactors: { [key: string]: number } = { Licence: 85/92, bengali: 65/92, kdm_850: 78/92, desi_bengali: 58/92 };
    pureGoldEq = oldWeight * (oldPurityFactors[oldType] || 65/92);
  }

  const deductionInGrams = toFixedTrim(Math.max(0, oldWeight - pureGoldEq), 3);
  pureGoldEq = toFixedTrim(pureGoldEq, 3);
  const deficitWeight = toFixedTrim(newWeight - pureGoldEq, 3);

  const newGoldPriceRatio: { [key: string]: number } = { Licence: 0.92, bengali: 0.75, kdm_850: 0.85, desi_bengali: 0.65 };
  const pricePerGramNew = (price24ct * (newGoldPriceRatio[newType] || 0.91)) / 10;
  const newGoldValue = pricePerGramNew * newWeight;

  let totalMakingCharge = 0;
  if (makingType === "fixed") {
    totalMakingCharge = makingValue;
  } else if (makingType === "percent") {
    totalMakingCharge = (makingValue / 100) * newGoldValue;
  } else if (makingType === "pergram") {
    totalMakingCharge = makingValue * newWeight;
  }
  totalMakingCharge = toFixedTrim(totalMakingCharge);

  const result: OldToNewBillDetails = {
    id: Date.now(),
    billType: "oldToNew",
    date: new Date().toISOString(),
    customerName,
    customerMobile,
    oldWeight,
    oldType,
    newWeight,
    newType,
    price24ct,
    makingType,
    makingValue,
    gstPercent,
    pureGoldEq,
    deductionInGrams,
    deficitWeight,
    totalMakingCharge,
  };

  if (deficitWeight < 0) {
    // Excess gold is turned in, which translates to immediate cash balances or credit deductions
    const excessGoldInGrams = Math.abs(deficitWeight);
    const creditValue = toFixedTrim(excessGoldInGrams * pricePerGramNew);
    
    let finalPayable = 0;
    let finalRefundable = 0;

    if (totalMakingCharge > creditValue) {
      const payableMakingCharge = totalMakingCharge - creditValue;
      const gstOnPayable = payableMakingCharge * (gstPercent / 100);
      finalPayable = toFixedTrim(payableMakingCharge + gstOnPayable);
    } else {
      finalRefundable = toFixedTrim(creditValue - totalMakingCharge);
    }

    result.excessGoldInGrams = excessGoldInGrams;
    result.creditValue = creditValue;
    result.finalPayable = finalPayable;
    result.finalRefundable = finalRefundable;
  } else {
    // Metal deficit must be compensated at raw standard spot index fees
    const costOfDeficitGold = toFixedTrim(deficitWeight * pricePerGramNew);
    const subtotal = costOfDeficitGold + totalMakingCharge;
    const gstAmount = toFixedTrim(subtotal * (gstPercent / 100));
    const totalPayable = toFixedTrim(subtotal + gstAmount);

    result.costOfDeficitGold = costOfDeficitGold;
    result.subtotal = subtotal;
    result.gstAmount = gstAmount;
    result.totalPayable = totalPayable;
  }

  return result;
}

export function calculateExchangeDetails(params: {
  customerName: string;
  customerPhone: string;
  newWeight: number;
  newPrice10g: number;
  labourType: "pergram" | "percent" | "fixed";
  labourValue: number;
  oldWeight: number;
  oldPrice10g: number;
  purity: number;
  gstPercent: number;
  includeGst: boolean;
  exchangeMode?: "general" | "nakmachi";
  billType: "exchange" | "silverExchange";
}): ExchangeBillDetails {
  const {
    customerName,
    customerPhone,
    newWeight,
    newPrice10g,
    labourType,
    labourValue,
    oldWeight,
    oldPrice10g,
    purity,
    gstPercent,
    includeGst,
    exchangeMode,
    billType
  } = params;

  const baseNewValue = toFixedTrim((newPrice10g / 10) * newWeight);
  
  let labourAmount = 0;
  if (labourType === "fixed") {
    labourAmount = labourValue;
  } else if (labourType === "percent") {
    labourAmount = (labourValue / 100) * baseNewValue;
  } else if (labourType === "pergram") {
    labourAmount = labourValue * newWeight;
  }
  labourAmount = toFixedTrim(labourAmount);
  
  const newGross = toFixedTrim(baseNewValue + labourAmount);
  const oldNet = toFixedTrim((oldPrice10g / 10) * oldWeight * (purity / 100));
  const balance = toFixedTrim(newGross - oldNet);

  let gstOnPayable = 0;
  if (includeGst && balance > 0) {
    gstOnPayable = toFixedTrim(balance * (gstPercent / 100));
  }

  const finalPayable = toFixedTrim(balance + gstOnPayable);

  return {
    id: Date.now(),
    billType,
    date: new Date().toISOString(),
    customerName,
    customerPhone,
    newWeight,
    newPrice10g,
    labourType,
    labourValue,
    oldWeight,
    oldPrice10g,
    purity,
    gstPercent,
    includeGst,
    baseNewValue,
    labourAmount,
    newGross,
    oldNet,
    balance,
    gstOnPayable,
    finalPayable,
    exchangeMode
  };
}

// Interest and Loan ledger tracking structure algorithms
export interface LoanCalculationResult {
  durationText: string;
  finalPrincipal: number;
  totalInterest: number;
  grandTotal: number;
  discountAmount: number;
  finalPayable: number;
  breakdown: Array<{
    fromDateStr: string;
    toDateStr: string;
    principal: number;
    durationStr: string;
    interest: number;
  }>;
}

export function calculateLoanInterest(
  transactions: LoanTransaction[],
  endDateInput: string,
  interestType: "percent" | "fixed",
  interestRateVal: number,
  advanceAmount: number,
  lang: "en" | "bn"
): LoanCalculationResult | null {
  if (transactions.length === 0 || !endDateInput) return null;

  const endDate = new Date(endDateInput);
  let principal = 0;
  let totalInterest = 0;
  let defaultTotalInterest = 0; // Baseline calculation at 3%
  const breakdown: LoanCalculationResult["breakdown"] = [];

  const tSorted = [...transactions].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  for (let i = 0; i < tSorted.length; i++) {
    const trans = tSorted[i];
    const transDate = new Date(trans.date);
    if (transDate > endDate) continue;

    let nextDate = endDate;
    if (i < tSorted.length - 1) {
      const nextTransDate = new Date(tSorted[i + 1].date);
      if (nextTransDate < endDate) nextDate = nextTransDate;
    }

    if (trans.type === "borrow") {
      principal += trans.amount;
    } else {
      principal -= trans.amount;
    }

    const timeDiff = nextDate.getTime() - transDate.getTime();
    const days = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
    let segmentInterest = 0;
    let durationStr = `0 ${lang === "en" ? "days" : "দিন"}`;

    if (days > 0 && principal > 0) {
      let months = Math.floor(days / 30);
      let remDays = days % 30;

      let calcMonths = months;
      let calcRemDays = remDays;

      // Adjust traditional cycle - if remaining days exceed 7, it rounds to the entire next month
      if (remDays >= 7) {
        calcMonths += 1;
        calcRemDays = 0;
      }

      if (interestType === "percent") {
        const mRate = interestRateVal / 100;
        const dRate = mRate / 30;
        segmentInterest = (principal * calcMonths * mRate) + (principal * calcRemDays * dRate);
      } else {
        segmentInterest = (calcMonths * interestRateVal) + (calcRemDays * (interestRateVal / 30));
      }

      // Default baseline comparison at 3% monthly yield
      const defaultMRate = 3 / 100;
      const defaultDRate = defaultMRate / 30;
      const defaultSegmentInt = (principal * calcMonths * defaultMRate) + (principal * calcRemDays * defaultDRate);
      defaultTotalInterest += defaultSegmentInt;

      totalInterest += segmentInterest;
      durationStr = `${months > 0 ? months + " " + (lang === "en" ? "months" : "মাস") + " " : ""}${remDays} ${lang === "en" ? "days" : "দিন"}`;

      breakdown.push({
        fromDateStr: transDate.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "2-digit" }),
        toDateStr: nextDate.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "2-digit" }),
        principal,
        durationStr,
        interest: Math.round(segmentInterest),
      });
    }
  }

  // Duration calculations
  const start = new Date(tSorted[0].date);
  let durationText = "-";
  if (endDate >= start) {
    let y = endDate.getFullYear() - start.getFullYear();
    let m = endDate.getMonth() - start.getMonth();
    let d = endDate.getDate() - start.getDate();
    if (d < 0) {
      m--;
      d += new Date(endDate.getFullYear(), endDate.getMonth(), 0).getDate();
    }
    if (m < 0) {
      y--;
      m += 12;
    }
    const parts: string[] = [];
    if (lang === "en") {
      if (y > 0) parts.push(`${y} year${y > 1 ? "s" : ""}`);
      if (m > 0) parts.push(`${m} month${m > 1 ? "s" : ""}`);
      if (d > 0) parts.push(`${d} day${d > 1 ? "s" : ""}`);
    } else {
      if (y > 0) parts.push(`${y} বছর`);
      if (m > 0) parts.push(`${m} মাস`);
      if (d > 0) parts.push(`${d} দিন`);
    }
    durationText = parts.length ? parts.join(", ") : `0 ${lang === "en" ? "days" : "দিন"}`;
  }

  const grandTotal = principal + Math.round(totalInterest);
  const discountAmount = Math.max(0, Math.round(defaultTotalInterest) - Math.round(totalInterest));
  const finalPayable = grandTotal - advanceAmount;

  return {
    durationText,
    finalPrincipal: principal,
    totalInterest: Math.round(totalInterest),
    grandTotal,
    discountAmount,
    finalPayable,
    breakdown,
  };
}
