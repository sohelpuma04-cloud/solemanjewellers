import React from "react";
import { ArrowLeftRight, ChevronDown, ChevronUp, Save, Eye, RefreshCw, Layers } from "lucide-react";
import { formatGramsToVoriAnaKuch, toFixedTrim, calculateExchangeDetails } from "../utils/calculations";

interface ExchangeTabsProps {
  lang: "bn" | "en";
  prices: {
    goldPrice: number;
    oldGoldPriceGeneral: number;
    oldGoldPriceNakmachi: number;
    newSilverPrice: number;
    oldSilverPrice: number;
  };
  gstPercent: number;
  metal: "gold" | "silver";
  onSaveBill: (bill: any) => void;
  onPreviewBill: (bill: any) => void;
  t: (key: string) => string;
}

export const ExchangeTabs: React.FC<ExchangeTabsProps> = ({
  lang,
  prices,
  gstPercent,
  metal,
  onSaveBill,
  onPreviewBill,
  t,
}) => {
  const isGold = metal === "gold";

  // Mode toggling
  const [exchangeMode, setExchangeMode] = React.useState<"general" | "nakmachi">("general");
  const [silverMode, setSilverMode] = React.useState<"general" | "sell">("general");

  // Inbound customer data
  const [customerName, setCustomerName] = React.useState("");
  const [customerPhone, setCustomerPhone] = React.useState("");

  // New item params
  const [newWeight, setNewWeight] = React.useState<number>(0);
  const [newWeightInAna, setNewWeightInAna] = React.useState("");
  const [newPrice10g, setNewPrice10g] = React.useState<number>(isGold ? 140000 : 2050);
  const [labourType, setLabourType] = React.useState<"percent" | "pergram" | "fixed">("percent");
  const [labourValue, setLabourValue] = React.useState<number>(12);

  // Old Trade-in params
  const [oldWeight, setOldWeight] = React.useState<number>(0);
  const [oldWeightInAna, setOldWeightInAna] = React.useState("");
  const [oldPrice10g, setOldPrice10g] = React.useState<number>(isGold ? 138000 : 1700);
  const [purity, setPurity] = React.useState<number>(isGold ? 65 : 65);

  const [includeGst, setIncludeGst] = React.useState(true);
  const [showFullCalc, setShowFullCalc] = React.useState(false);

  // Synchronize on Spot Rates changes
  React.useEffect(() => {
    if (isGold) {
      if (exchangeMode === "nakmachi") {
        setNewPrice10g(toFixedTrim(prices.goldPrice * 0.65));
        setLabourType("percent");
        setLabourValue(15);
        setOldPrice10g(prices.oldGoldPriceNakmachi || 138000);
        setPurity(35);
      } else {
        setNewPrice10g(prices.goldPrice);
        setLabourType("percent");
        setLabourValue(12);
        setOldPrice10g(prices.oldGoldPriceGeneral || 140000);
        setPurity(65);
      }
    } else {
      if (silverMode === "sell") {
        setNewPrice10g(prices.newSilverPrice || 2050);
        setLabourType("percent");
        setLabourValue(12);
        setOldPrice10g(1800);
        setPurity(30);
      } else {
        setNewPrice10g(prices.newSilverPrice || 2050);
        setLabourType("percent");
        setLabourValue(12);
        setOldPrice10g(prices.oldSilverPrice || 1700);
        setPurity(65);
      }
    }
  }, [prices, exchangeMode, silverMode, isGold]);

  const handleNewGramsChange = (valStr: string) => {
    const grams = parseFloat(valStr) || 0;
    setNewWeight(grams);
    if (grams > 0) {
      setNewWeightInAna((grams * (16 / 11.664)).toFixed(3));
    } else {
      setNewWeightInAna("");
    }
  };

  const handleNewAnaChange = (valStr: string) => {
    setNewWeightInAna(valStr);
    const anas = parseFloat(valStr) || 0;
    if (anas > 0) {
      setNewWeight(toFixedTrim(anas / (16 / 11.664), 3));
    } else {
      setNewWeight(0);
    }
  };

  const handleOldGramsChange = (valStr: string) => {
    const grams = parseFloat(valStr) || 0;
    setOldWeight(grams);
    if (grams > 0) {
      setOldWeightInAna((grams * (16 / 11.664)).toFixed(3));
    } else {
      setOldWeightInAna("");
    }
  };

  const handleOldAnaChange = (valStr: string) => {
    setOldWeightInAna(valStr);
    const anas = parseFloat(valStr) || 0;
    if (anas > 0) {
      setOldWeight(toFixedTrim(anas / (16 / 11.664), 3));
    } else {
      setOldWeight(0);
    }
  };

  const handleQuickPurity = (val: number) => {
    setPurity(val);
  };

  const bill = calculateExchangeDetails({
    customerName,
    customerPhone,
    newWeight,
    newPrice10g,
    labourType,
    labourValue,
    oldWeight,
    oldPrice10g,
    purity,
    gstPercent,
    includeGst,
    exchangeMode: isGold ? exchangeMode : undefined,
    billType: isGold ? "exchange" : "silverExchange"
  });

  const handleSave = () => {
    if (newWeight <= 0 && oldWeight <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    const savedBill = {
      ...bill,
      id: Date.now(),
      date: new Date().toISOString(),
    };
    onSaveBill(savedBill);
  };

  const handlePreview = () => {
    if (newWeight <= 0 && oldWeight <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    const previewItem = {
      ...bill,
      id: Date.now(),
      date: new Date().toISOString(),
    };
    onPreviewBill(previewItem);
  };

  const handleReset = () => {
    setCustomerName("");
    setCustomerPhone("");
    setNewWeight(0);
    setNewWeightInAna("");
    setOldWeight(0);
    setOldWeightInAna("");
    setIncludeGst(true);
    setShowFullCalc(false);
  };

  const isDebtOwedToShop = bill.balance > 0;
  const isZeroSettle = Math.abs(bill.balance) <= 0.005;

  let highlightTitle = t("balance");
  let highlightValue = "₹0";
  let highlightColor = "text-slate-600 dark:text-slate-400";

  if (isDebtOwedToShop) {
    highlightTitle = t("custPay");
    highlightValue = `₹${bill.finalPayable.toLocaleString("en-IN")}`;
    highlightColor = "text-sky-600 dark:text-sky-400";
  } else if (!isZeroSettle) {
    highlightTitle = t("shopReturn");
    highlightValue = `₹${Math.abs(bill.balance).toLocaleString("en-IN")}`;
    highlightColor = "text-rose-600 dark:text-rose-400";
  }

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-slate-200/50 dark:border-slate-800/80 max-w-3xl mx-auto">
      {/* Active Metal Mode choices subheader toolbar */}
      <div className="flex bg-slate-100 dark:bg-slate-950 p-1 rounded-xl mb-6 border border-slate-200/40 dark:border-slate-800/60 shadow-xs">
        {isGold ? (
          <>
            <button
              onClick={() => setExchangeMode("general")}
              className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                exchangeMode === "general"
                  ? "bg-sky-500 text-white shadow-md shadow-sky-500/20"
                  : "text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900"
              }`}
            >
              <ArrowLeftRight className="w-4 h-4" />
              {t("modeGen")}
            </button>
            <button
              onClick={() => setExchangeMode("nakmachi")}
              className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                exchangeMode === "nakmachi"
                  ? "bg-sky-500 text-white shadow-md shadow-sky-500/20"
                  : "text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900"
              }`}
            >
              <Layers className="w-4 h-4" />
              {t("modeNak")}
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => setSilverMode("general")}
              className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                silverMode === "general"
                  ? "bg-sky-500 text-white shadow-md shadow-sky-500/20"
                  : "text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900"
              }`}
            >
              <ArrowLeftRight className="w-4 h-4" />
              {t("modeGen")}
            </button>
            <button
              onClick={() => setSilverMode("sell")}
              className={`flex-1 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-300 flex items-center justify-center gap-1.5 cursor-pointer ${
                silverMode === "sell"
                  ? "bg-sky-500 text-white shadow-md shadow-sky-500/20"
                  : "text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900"
              }`}
            >
              <Layers className="w-4 h-4" />
              {t("modeSell")}
            </button>
          </>
        )}
      </div>

      {/* Main Panel title tag */}
      <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4 mb-6">
        <div className="p-2 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400">
          <ArrowLeftRight className="w-6 h-6" />
        </div>
        <h3 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 uppercase tracking-wide">
          {isGold ? t("goldExTitle") : t("silverExTitle")}
        </h3>
      </div>

      {/* customer input boxes */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 mb-6">
        <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
          {t("custInfo")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("custName")}</label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={t("enterName")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("phone")}</label>
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder={t("enterPhone")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm"
            />
          </div>
        </div>
      </fieldset>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* New jewelry specification parameters */}
        <div className="p-4 rounded-xl border border-sky-500/10 bg-sky-500/5 dark:bg-sky-950/5 space-y-4">
          <h4 className="text-sm font-black text-sky-600 dark:text-sky-400 uppercase tracking-wider border-b border-sky-500/10 pb-2">
            📦 {isGold ? t("newJewelry") : t("newSilver")}
          </h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("weightG")}</label>
              <input
                type="number"
                step="0.001"
                value={newWeight || ""}
                onChange={(e) => handleNewGramsChange(e.target.value)}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-xs font-mono"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("weightAna")}</label>
              <input
                type="number"
                step="0.001"
                value={newWeightInAna || ""}
                onChange={(e) => handleNewAnaChange(e.target.value)}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-xs font-mono"
              />
            </div>
          </div>
          <div className="text-xs text-center text-sky-600 dark:text-sky-400 font-mono italic">
            {formatGramsToVoriAnaKuch(newWeight, lang)}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("dailyPrice")}</label>
            <input
              type="number"
              value={newPrice10g || ""}
              onChange={(e) => setNewPrice10g(Math.max(0, parseFloat(e.target.value) || 0))}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-sky-600 dark:text-sky-400 text-xs font-mono"
            />
          </div>
          <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t("making")}</h5>
          <div className="grid grid-cols-2 gap-3">
            <select
              value={labourType}
              onChange={(e) => setLabourType(e.target.value as any)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 text-xs font-medium cursor-pointer"
            >
              <option value="percent">{t("mcPercent")}</option>
              <option value="pergram">{t("mcPerGram")}</option>
              <option value="fixed">{t("mcFixed")}</option>
            </select>
            <input
              type="number"
              value={labourValue || ""}
              onChange={(e) => setLabourValue(Math.max(0, parseFloat(e.target.value) || 0))}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 text-xs font-mono"
            />
          </div>
        </div>

        {/* Trade in item params */}
        <div className="p-4 rounded-xl border border-rose-500/10 bg-rose-500/5 dark:bg-rose-950/5 space-y-4">
          <h4 className="text-sm font-black text-rose-600 dark:text-rose-400 uppercase tracking-wider border-b border-rose-500/10 pb-2">
            ♻ {isGold ? t("oldJewelry") : t("oldSilver")}
          </h4>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("weightG")}</label>
              <input
                type="number"
                step="0.001"
                value={oldWeight || ""}
                onChange={(e) => handleOldGramsChange(e.target.value)}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-xs font-mono"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("weightAna")}</label>
              <input
                type="number"
                step="0.001"
                value={oldWeightInAna || ""}
                onChange={(e) => handleOldAnaChange(e.target.value)}
                className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-xs font-mono"
              />
            </div>
          </div>
          <div className="text-xs text-center text-rose-600 dark:text-rose-400 font-mono italic">
            {formatGramsToVoriAnaKuch(oldWeight, lang)}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("dailyPrice")}</label>
            <input
              type="number"
              value={oldPrice10g || ""}
              onChange={(e) => setOldPrice10g(Math.max(0, parseFloat(e.target.value) || 0))}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-rose-600 dark:text-rose-400 text-xs font-mono"
            />
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center mb-0.5">
              <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("purityPct")}</label>
              {isGold && (
                <div className="flex gap-1">
                  <button
                    onClick={() => handleQuickPurity(85)}
                    className="px-1.5 py-0.5 rounded-sm bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-[9px] font-black cursor-pointer text-slate-600 dark:text-slate-300"
                  >
                    H-Mark
                  </button>
                  <button
                    onClick={() => handleQuickPurity(70)}
                    className="px-1.5 py-0.5 rounded-sm bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-[9px] font-black cursor-pointer text-slate-600 dark:text-slate-300"
                  >
                    KDM
                  </button>
                  <button
                    onClick={() => handleQuickPurity(65)}
                    className="px-1.5 py-0.5 rounded-sm bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-[9px] font-black cursor-pointer text-slate-600 dark:text-slate-300"
                  >
                    Bangla
                  </button>
                </div>
              )}
            </div>
            <input
              type="number"
              value={purity || ""}
              onChange={(e) => setPurity(Math.min(100, Math.max(0, parseFloat(e.target.value) || 0)))}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-rose-600 dark:text-rose-400 text-xs font-mono"
            />
            <span className="text-[10px] italic text-slate-400 text-right font-mono">
              ~ {toFixedTrim(100 - purity)}% {t("cutOff")}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3 p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200/50 dark:border-slate-800 rounded-xl mb-6 shadow-2xs">
        <input
          type="checkbox"
          id={`taxRequiredEx-${metal}`}
          checked={includeGst}
          onChange={(e) => setIncludeGst(e.target.checked)}
          className="w-4 h-4 text-sky-500 rounded-sm border-slate-300 focus:focus:ring-sky-500/50 cursor-pointer"
        />
        <label
          htmlFor={`taxRequiredEx-${metal}`}
          className="text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer select-none"
        >
          {t("addGst")} ({gstPercent}%)
        </label>
      </div>

      {/* Pricing summary */}
      <div className="p-5 rounded-2xl bg-sky-500/5 border border-sky-500/20 shadow-xs mb-6 relative overflow-hidden">
        <div className="absolute -right-12 -bottom-12 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl" />

        <div className="flex flex-col gap-4 relative z-10">
          <div className="flex justify-between items-baseline flex-wrap gap-2">
            <span className="text-sm font-bold text-slate-600 dark:text-slate-400">{highlightTitle}</span>
            <span className={`text-3xl font-black font-mono ${highlightColor}`}>{highlightValue}</span>
          </div>

          <div className="border-t border-slate-200/50 dark:border-slate-800/80 pt-3 flex flex-col gap-1">
            <button
              onClick={() => setShowFullCalc(!showFullCalc)}
              className="self-start text-xs font-extrabold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer"
            >
              {t("viewFullCalc")}
              {showFullCalc ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showFullCalc && (
              <div className="flex flex-col gap-2 mt-3 p-3 rounded-lg bg-slate-50/50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/50 text-xs font-medium text-slate-600 dark:text-slate-400 leading-6 font-semibold">
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1">
                  <span>{t("newJewelryTotal")}:</span>
                  <span className="font-bold font-mono">₹{bill.newGross.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                  <span>{t("oldJewelryTotal")} ({purity}% purity):</span>
                  <span className="font-bold font-mono">₹{bill.oldNet.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                  <span>{t("balance")}:</span>
                  <span className="font-bold font-mono">₹{bill.balance.toLocaleString("en-IN")}</span>
                </div>
                {includeGst && bill.balance > 0 && (
                  <div className="flex justify-between pt-1 mt-1">
                    <span>{t("gst")} ({gstPercent}% on payable):</span>
                    <span className="font-bold font-mono text-xs">₹{bill.gstOnPayable.toLocaleString("en-IN")}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={handleSave}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-linear-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white font-extrabold text-sm uppercase shadow-md transition-all hover:-translate-y-0.5"
        >
          <Save className="w-4 h-4" />
          {t("savePrint")}
        </button>
        <button
          onClick={handlePreview}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-extrabold text-sm uppercase transition-all"
        >
          <Eye className="w-4 h-4" />
          {t("previewBtn")}
        </button>
        <button
          onClick={handleReset}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-extrabold text-sm uppercase transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          {t("resetBtn")}
        </button>
      </div>
    </div>
  );
};
