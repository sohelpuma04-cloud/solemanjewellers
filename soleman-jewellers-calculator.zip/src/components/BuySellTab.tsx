import React from "react";
import { ChevronDown, ChevronUp, Save, Eye, RefreshCw, Calculator, User, Phone, Coins, Weight } from "lucide-react";
import { formatGramsToVoriAnaKuch, toFixedTrim, calculateProfitDetails } from "../utils/calculations";

interface BuySellTabProps {
  lang: "bn" | "en";
  prices: { goldPrice: number; oldGoldPriceGeneral: number };
  gstPercent: number;
  onSaveBill: (bill: any) => void;
  onPreviewBill: (bill: any) => void;
  t: (key: string) => string;
}

export const BuySellTab: React.FC<BuySellTabProps> = ({
  lang,
  prices,
  gstPercent,
  onSaveBill,
  onPreviewBill,
  t,
}) => {
  // Inputs state
  const [customerName, setCustomerName] = React.useState("");
  const [customerPhone, setCustomerPhone] = React.useState("");
  const [basePrice24ct, setBasePrice24ct] = React.useState<number>(140000);
  const [weightGrams, setWeightGrams] = React.useState<number>(10);
  const [weightAna, setWeightAna] = React.useState<string>("");
  const [makingChargeType, setMakingChargeType] = React.useState<"percent" | "pergram" | "fixed">("percent");
  const [makingChargeValue, setMakingChargeValue] = React.useState<number>(12);
  const [goldQuality, setGoldQuality] = React.useState<string>("Licence");
  
  const [showFullCalc, setShowFullCalc] = React.useState(false);
  const [isCalculated, setIsCalculated] = React.useState(false);

  // Sync pricing changes on spot price updates
  React.useEffect(() => {
    if (prices.goldPrice > 0) {
      setBasePrice24ct(prices.goldPrice);
    }
  }, [prices.goldPrice]);

  // Handle traditional weight syncs
  const handleGramsChange = (valStr: string) => {
    const grams = parseFloat(valStr) || 0;
    setWeightGrams(grams);
    if (grams > 0) {
      const anas = grams * (16 / 11.664);
      setWeightAna(anas.toFixed(3));
    } else {
      setWeightAna("");
    }
  };

  const handleAnaChange = (valStr: string) => {
    setWeightAna(valStr);
    const anas = parseFloat(valStr) || 0;
    if (anas > 0) {
      setWeightGrams(toFixedTrim(anas / (16 / 11.664), 3));
    } else {
      setWeightGrams(0);
    }
  };

  // Automatically update making parameters depending on gold criteria selections
  React.useEffect(() => {
    if (makingChargeType === "percent") {
      if (goldQuality === "bengali" || goldQuality === "desi_bengali") {
        setMakingChargeValue(15);
      } else if (goldQuality === "kdm") {
        setMakingChargeValue(13);
      } else {
        setMakingChargeValue(12);
      }
    }
  }, [goldQuality, makingChargeType]);

  const qualityOptions: { [key: string]: string } = {
    Licence: t("hm22k"),
    kdm: t("kdm20k"),
    bengali: t("bangla18k"),
    desi_bengali: t("desi15k"),
  };

  const { details, total } = calculateProfitDetails({
    basePrice24ct,
    weightGrams,
    quality: goldQuality,
    makingChargeType,
    makingChargeValue,
    gstPercent,
    customerName,
    customerPhone,
    qualityOptions,
  });

  const handleSave = () => {
    if (weightGrams <= 0 || basePrice24ct <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    // Deep clone active details configuration and tag unique save parameters
    const savedBill = {
      ...details,
      id: Date.now(),
      date: new Date().toISOString(),
      qualityName: qualityOptions[goldQuality]
    };
    onSaveBill(savedBill);
  };

  const handlePreview = () => {
    if (weightGrams <= 0 || basePrice24ct <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    const previewItem = {
      ...details,
      id: Date.now(),
      date: new Date().toISOString(),
      qualityName: qualityOptions[goldQuality]
    };
    onPreviewBill(previewItem);
  };

  const handleReset = () => {
    setCustomerName("");
    setCustomerPhone("");
    setWeightGrams(10);
    setWeightAna((10 * (16 / 11.664)).toFixed(3));
    setMakingChargeType("percent");
    setMakingChargeValue(12);
    setGoldQuality("Licence");
    setShowFullCalc(false);
  };

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-slate-200/50 dark:border-slate-800/80 max-w-3xl mx-auto">
      {/* Tab Title banner */}
      <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4 mb-6">
        <div className="p-2 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400">
          <Calculator className="w-6 h-6" />
        </div>
        <h3 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 uppercase tracking-wide">
          {t("bsTitle")}
        </h3>
      </div>

      {/* Customer Credentials info block */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 mb-6">
        <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
          {t("custInfo")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5 leading-none">
              <User className="w-3.5 h-3.5" />
              {t("custName")}
            </label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={t("enterName")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5 leading-none">
              <Phone className="w-3.5 h-3.5" />
              {t("phone")}
            </label>
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder={t("enterPhone")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm"
            />
          </div>
        </div>
      </fieldset>

      {/* Calculator Logic elements details */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5 leading-none">
            <Coins className="w-3.5 h-3.5 text-amber-500" />
            {t("price24ct")} (₹)
          </label>
          <input
            type="number"
            value={basePrice24ct || ""}
            onChange={(e) => setBasePrice24ct(Math.max(0, parseFloat(e.target.value) || 0))}
            className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm font-mono"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 leading-none">
            {t("gst")} (%)
          </label>
          <input
            type="number"
            step="0.1"
            value={gstPercent}
            disabled
            className="lg:p-3 p-2.5 rounded-lg border border-slate-100 dark:border-slate-900 bg-slate-100/50 dark:bg-slate-950 text-slate-500 dark:text-slate-500 font-bold text-sm font-mono cursor-not-allowed"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5 leading-none">
            <Weight className="w-3.5 h-3.5 text-sky-500" />
            {t("weightG")}
          </label>
          <input
            type="number"
            step="0.001"
            value={weightGrams || ""}
            onChange={(e) => handleGramsChange(e.target.value)}
            className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm font-mono"
            placeholder="0.000"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5 leading-none">
            <Weight className="w-3.5 h-3.5 text-sky-500" />
            {t("weightAna")}
          </label>
          <input
            type="number"
            step="0.001"
            value={weightAna || ""}
            onChange={(e) => handleAnaChange(e.target.value)}
            className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm font-mono"
            placeholder="0.000"
          />
        </div>
        {/* Helper weight description tag */}
        <div className="flex flex-col gap-1 justify-end pb-1.5">
          <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-500/5 border border-emerald-500/15 py-1.5 px-2.5 rounded-md text-center italic drop-shadow-xs font-mono">
            {formatGramsToVoriAnaKuch(weightGrams, lang)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 leading-none">
            {t("makingType")}
          </label>
          <select
            value={makingChargeType}
            onChange={(e) => setMakingChargeType(e.target.value as any)}
            className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-semibold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm cursor-pointer"
          >
            <option value="pergram">{t("mcPerGram")}</option>
            <option value="percent">{t("mcPercent")}</option>
            <option value="fixed">{t("mcFixed")}</option>
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 leading-none">
            {t("makingAmount")}
          </label>
          <input
            type="number"
            step="0.1"
            value={makingChargeValue || ""}
            onChange={(e) => setMakingChargeValue(Math.max(0, parseFloat(e.target.value) || 0))}
            className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm font-mono"
          />
        </div>
      </div>

      <div className="flex flex-col gap-1 mb-6">
        <label className="text-xs font-bold text-slate-600 dark:text-slate-400 leading-none mb-1">
          {t("goldQual")}
        </label>
        <select
          value={goldQuality}
          onChange={(e) => setGoldQuality(e.target.value)}
          className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-amber-600 dark:text-amber-400 focus:outline-hidden focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm cursor-pointer"
        >
          {Object.keys(qualityOptions).map((key) => (
            <option key={key} value={key} className="font-bold">
              {qualityOptions[key]}
            </option>
          ))}
        </select>
      </div>

      {/* Live calculations outcome card block */}
      <div className="p-5 rounded-2xl bg-sky-500/5 border border-sky-500/20 shadow-xs mb-6 relative overflow-hidden">
        {/* Glow vector back */}
        <div className="absolute -right-12 -bottom-12 w-32 h-32 bg-sky-500/10 rounded-full blur-2xl" />

        <div className="flex flex-col gap-4 relative z-10">
          <div className="flex justify-between items-baseline flex-wrap gap-2">
            <span className="text-sm font-bold text-slate-600 dark:text-slate-400">
              {t("totalPriceGST")}
            </span>
            <span className="text-3xl font-black text-sky-600 dark:text-sky-400 font-mono">
              ₹{total.toLocaleString("en-IN")}
            </span>
          </div>

          <div className="border-t border-slate-200/50 dark:border-slate-800/80 pt-3 flex flex-col gap-1">
            <button
              onClick={() => setShowFullCalc(!showFullCalc)}
              className="self-start text-xs font-extrabold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer transition-colors"
            >
              {t("viewFullCalc")}
              {showFullCalc ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showFullCalc && (
              <div className="flex flex-col gap-2 mt-3 p-3 rounded-lg bg-slate-50/50 dark:bg-slate-950/55 border border-slate-100 dark:border-slate-800/50 text-xs font-medium text-slate-600 dark:text-slate-400 leading-relaxed drop-shadow-sm leading-6">
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1">
                  <span>{t("goldValue")} ({qualityOptions[goldQuality]}):</span>
                  <span className="font-bold font-mono">₹{details.totalGoldValue.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                  <span>
                    {t("totMaking")} ({makingChargeType === "percent" ? `${makingChargeValue}%` : makingChargeType === "pergram" ? `₹${makingChargeValue}/g` : t("fixed")}):
                  </span>
                  <span className="font-bold font-mono">₹{details.totalMakingCharge.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between pt-1 mt-1">
                  <span>{t("gst")} ({details.gstPercent}%):</span>
                  <span className="font-bold font-mono">₹{details.gstAmount.toLocaleString("en-IN")}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Interaction control bar */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={handleSave}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-linear-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white font-extrabold text-sm uppercase shadow-md transition-all hover:-translate-y-0.5"
        >
          <Save className="w-4 h-4" />
          {t("savePrint")}
        </button>
        <button
          onClick={handlePreview}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-extrabold text-sm uppercase transition-all"
        >
          <Eye className="w-4 h-4" />
          {t("previewBtn")}
        </button>
        <button
          onClick={handleReset}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-extrabold text-sm uppercase transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          {t("resetBtn")}
        </button>
      </div>
    </div>
  );
};
