import React from "react";
import { Recycle, ChevronDown, ChevronUp, Save, Eye, RefreshCw, Scale } from "lucide-react";
import { formatGramsToVoriAnaKuch, toFixedTrim, calculateOldToNewDetails } from "../utils/calculations";

interface OldToNewTabProps {
  lang: "bn" | "en";
  prices: { goldPrice: number };
  gstPercent: number;
  onSaveBill: (bill: any) => void;
  onPreviewBill: (bill: any) => void;
  t: (key: string) => string;
}

export const OldToNewTab: React.FC<OldToNewTabProps> = ({
  lang,
  prices,
  gstPercent,
  onSaveBill,
  onPreviewBill,
  t,
}) => {
  const [customerName, setCustomerName] = React.useState("");
  const [customerMobile, setCustomerMobile] = React.useState("");

  // Old gold inputs
  const [oldWeight, setOldWeight] = React.useState<number>(10);
  const [oldWeightInAna, setOldWeightInAna] = React.useState<string>("");
  const [oldType, setOldType] = React.useState<string>("desi_bengali");

  // New gold inputs
  const [newWeight, setNewWeight] = React.useState<number>(10);
  const [newWeightInAna, setNewWeightInAna] = React.useState<string>("");
  const [newType, setNewType] = React.useState<string>("Licence");

  // Cost and Craft controls
  const [price24ct, setPrice24ct] = React.useState<number>(140000);
  const [makingType, setMakingType] = React.useState<"percent" | "pergram" | "fixed">("percent");
  const [makingValue, setMakingValue] = React.useState<number>(9.99);

  const [showFullCalc, setShowFullCalc] = React.useState(false);

  React.useEffect(() => {
    if (prices.goldPrice > 0) {
      setPrice24ct(prices.goldPrice);
    }
  }, [prices.goldPrice]);

  // Initial loads
  React.useEffect(() => {
    setOldWeightInAna((10 * (16 / 11.664)).toFixed(3));
    setNewWeightInAna((10 * (16 / 11.664)).toFixed(3));
  }, []);

  const handleOldGramsChange = (valStr: string) => {
    const grams = parseFloat(valStr) || 0;
    setOldWeight(grams);
    if (grams > 0) {
      setOldWeightInAna((grams * (16 / 11.664)).toFixed(3));
    } else {
      setOldWeightInAna("");
    }
  };

  const handleOldAnaChange = (valStr: string) => {
    setOldWeightInAna(valStr);
    const anas = parseFloat(valStr) || 0;
    if (anas > 0) {
      setOldWeight(toFixedTrim(anas / (16 / 11.664), 3));
    } else {
      setOldWeight(0);
    }
  };

  const handleNewGramsChange = (valStr: string) => {
    const grams = parseFloat(valStr) || 0;
    setNewWeight(grams);
    if (grams > 0) {
      setNewWeightInAna((grams * (16 / 11.664)).toFixed(3));
    } else {
      setNewWeightInAna("");
    }
  };

  const handleNewAnaChange = (valStr: string) => {
    setNewWeightInAna(valStr);
    const anas = parseFloat(valStr) || 0;
    if (anas > 0) {
      setNewWeight(toFixedTrim(anas / (16 / 11.664), 3));
    } else {
      setNewWeight(0);
    }
  };

  const alloyTypes: { [key: string]: string } = {
    Licence: t("hm22k"),
    kdm_850: t("kdm20k"),
    bengali: t("bangla18k"),
    desi_bengali: t("desi15k"),
  };

  const bill = calculateOldToNewDetails({
    oldWeight,
    oldType,
    newWeight,
    newType,
    price24ct,
    makingType,
    makingValue,
    gstPercent,
    customerName,
    customerMobile,
  });

  const handleSave = () => {
    if (oldWeight <= 0 || newWeight <= 0 || price24ct <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    const savedBill = {
      ...bill,
      id: Date.now(),
      date: new Date().toISOString(),
      oldTypeLabel: alloyTypes[oldType],
      newTypeLabel: alloyTypes[newType]
    };
    onSaveBill(savedBill);
  };

  const handlePreview = () => {
    if (oldWeight <= 0 || newWeight <= 0 || price24ct <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    const previewItem = {
      ...bill,
      id: Date.now(),
      date: new Date().toISOString(),
      oldTypeLabel: alloyTypes[oldType],
      newTypeLabel: alloyTypes[newType]
    };
    onPreviewBill(previewItem);
  };

  const handleReset = () => {
    setCustomerName("");
    setCustomerMobile("");
    setOldWeight(10);
    setOldWeightInAna((10 * (16 / 11.664)).toFixed(3));
    setOldType("desi_bengali");
    setNewWeight(10);
    setNewWeightInAna((10 * (16 / 11.664)).toFixed(3));
    setNewType("Licence");
    setMakingType("percent");
    setMakingValue(9.99);
    setShowFullCalc(false);
  };

  // Determine totals format output
  const isRefunding = bill.deficitWeight < 0;
  const finalTitle = isRefunding ? t("shopReturn") : t("totalPayable");
  const finalValueStr = isRefunding
    ? `₹${(bill.finalRefundable || 0).toLocaleString("en-IN")}`
    : `₹${(bill.totalPayable || 0).toLocaleString("en-IN")}`;

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-slate-200/50 dark:border-slate-800/80 max-w-3xl mx-auto">
      {/* Title banner */}
      <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4 mb-6">
        <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
          <Recycle className="w-6 h-6" />
        </div>
        <h3 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 uppercase tracking-wide">
          {t("otnTitle")}
        </h3>
      </div>

      {/* Inputs - Customer details */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 mb-6">
        <legend className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest px-2 font-mono">
          {t("custInfo")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("custName")}</label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={t("enterName")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:focus:ring-2 focus:ring-emerald-500/50 focus:bg-white text-sm"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("phone")}</label>
            <input
              type="tel"
              value={customerMobile}
              onChange={(e) => setCustomerMobile(e.target.value)}
              placeholder={t("enterPhone")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:focus:ring-2 focus:ring-emerald-500/50 focus:bg-white text-sm"
            />
          </div>
        </div>
      </fieldset>

      {/* Grid section - Old jewelry against new asset */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Old melt trade in */}
        <div className="p-4 rounded-xl border border-rose-500/10 bg-rose-500/5/10 dark:bg-rose-950/10 space-y-4">
          <h4 className="text-sm font-black text-rose-600 dark:text-rose-400 uppercase tracking-wider border-b border-rose-500/10 pb-2">
            ♻ {t("oldGoldDetails")}
          </h4>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("oldWeightG")}</label>
            <input
              type="number"
              step="0.001"
              value={oldWeight || ""}
              onChange={(e) => handleOldGramsChange(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-sm font-mono"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("oldWeightAna")}</label>
            <input
              type="number"
              step="0.001"
              value={oldWeightInAna || ""}
              onChange={(e) => handleOldAnaChange(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-sm font-mono"
            />
          </div>
          <div className="text-xs text-center text-rose-600 dark:text-rose-400 font-mono italic">
            {formatGramsToVoriAnaKuch(oldWeight, lang)}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("oldType")}</label>
            <select
              value={oldType}
              onChange={(e) => setOldType(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-semibold text-rose-600 dark:text-rose-400 text-xs"
            >
              {Object.keys(alloyTypes).map((key) => (
                <option key={key} value={key}>
                  {alloyTypes[key]}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Desired new asset specs */}
        <div className="p-4 rounded-xl border border-sky-500/10 bg-sky-500/5/10 dark:bg-sky-950/10 space-y-4">
          <h4 className="text-sm font-black text-sky-600 dark:text-sky-400 uppercase tracking-wider border-b border-sky-500/10 pb-2">
            📦 {t("newGoldDetails")}
          </h4>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("newWeightG")}</label>
            <input
              type="number"
              step="0.001"
              value={newWeight || ""}
              onChange={(e) => handleNewGramsChange(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-sm font-mono"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("newWeightAna")}</label>
            <input
              type="number"
              step="0.001"
              value={newWeightInAna || ""}
              onChange={(e) => handleNewAnaChange(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-sm font-mono"
            />
          </div>
          <div className="text-xs text-center text-sky-600 dark:text-sky-400 font-mono italic">
            {formatGramsToVoriAnaKuch(newWeight, lang)}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("newType")}</label>
            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-semibold text-sky-600 dark:text-sky-400 text-xs"
            >
              {Object.keys(alloyTypes).map((key) => (
                <option key={key} value={key}>
                  {alloyTypes[key]}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Pricing index & craft parameter cards */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 mb-6">
        <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
          {t("priceCharge")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex flex-col gap-1 sm:col-span-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("price24ct")} (₹)</label>
            <input
              type="number"
              value={price24ct || ""}
              onChange={(e) => setPrice24ct(Math.max(0, parseFloat(e.target.value) || 0))}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-xs font-mono"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("makingType")}</label>
            <select
              value={makingType}
              onChange={(e) => setMakingType(e.target.value as any)}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 text-xs cursor-pointer"
            >
              <option value="percent">{t("mcPercent")}</option>
              <option value="pergram">{t("mcPerGram")}</option>
              <option value="fixed">{t("mcFixed")}</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("makingAmount")}</label>
            <input
              type="number"
              value={makingValue || ""}
              onChange={(e) => setMakingValue(Math.max(0, parseFloat(e.target.value) || 0))}
              className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-800 dark:text-slate-200 text-xs font-mono"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("gst")} (%)</label>
            <input
              type="number"
              value={gstPercent}
              disabled
              className="p-2.5 rounded-lg border border-slate-100 dark:border-slate-900 bg-slate-100/50 cursor-not-allowed text-slate-500 text-xs font-mono font-bold"
            />
          </div>
        </div>
      </fieldset>

      {/* Outcome value card block */}
      <div className="p-5 rounded-2xl bg-emerald-500/5 border border-emerald-500/20 shadow-xs mb-6 relative overflow-hidden">
        <div className="absolute -right-12 -bottom-12 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl" />

        <div className="flex flex-col gap-4 relative z-10">
          <div className="flex justify-between items-baseline flex-wrap gap-2">
            <span className="text-sm font-bold text-slate-600 dark:text-slate-400">{finalTitle}</span>
            <span className="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
              {finalValueStr}
            </span>
          </div>

          <div className="border-t border-slate-200/50 dark:border-slate-800/80 pt-3 flex flex-col gap-1">
            <button
              onClick={() => setShowFullCalc(!showFullCalc)}
              className="self-start text-xs font-extrabold text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 cursor-pointer"
            >
              {t("viewFullCalc")}
              {showFullCalc ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showFullCalc && (
              <div className="flex flex-col gap-2 mt-3 p-3 rounded-lg bg-slate-50/50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/50 text-xs font-medium text-slate-600 dark:text-slate-400 leading-6 font-semibold">
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1">
                  <span>{t("pureGoldRec")}:</span>
                  <span className="font-bold font-mono">
                    {bill.pureGoldEq.toFixed(3)}g ({formatGramsToVoriAnaKuch(bill.pureGoldEq, lang)})
                  </span>
                </div>
                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                  <span>{t("deducted")}:</span>
                  <span className="font-bold font-mono text-rose-500">
                    -{bill.deductionInGrams.toFixed(3)}g ({formatGramsToVoriAnaKuch(bill.deductionInGrams, lang)})
                  </span>
                </div>

                {bill.deficitWeight > 0 ? (
                  <>
                    <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                      <span>{t("extraGoldNeeded")}:</span>
                      <span className="font-bold font-mono text-rose-600">
                        {bill.deficitWeight.toFixed(3)}g ({formatGramsToVoriAnaKuch(bill.deficitWeight, lang)})
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                      <span>{t("extraGoldVal")}:</span>
                      <span className="font-bold font-mono">₹{bill.costOfDeficitGold?.toLocaleString("en-IN")}</span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                      <span>Excess Gold Gained:</span>
                      <span className="font-bold font-mono text-emerald-600">
                        {Math.abs(bill.deficitWeight).toFixed(3)}g
                      </span>
                    </div>
                    <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                      <span>{t("extraGoldCredit")}:</span>
                      <span className="font-bold font-mono">₹{bill.creditValue?.toLocaleString("en-IN")}</span>
                    </div>
                  </>
                )}

                <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                  <span>{t("totMaking")}:</span>
                  <span className="font-bold font-mono">₹{bill.totalMakingCharge.toLocaleString("en-IN")}</span>
                </div>

                {!isRefunding && (
                  <>
                    <div className="flex justify-between border-b border-dashed border-slate-200 dark:border-slate-800 pb-1 mt-1">
                      <span>{t("subtotal")}:</span>
                      <span className="font-bold font-mono">₹{bill.subtotal?.toLocaleString("en-IN")}</span>
                    </div>
                    <div className="flex justify-between pt-1 mt-1">
                      <span>{t("gst")} ({gstPercent}%):</span>
                      <span className="font-bold font-mono">₹{bill.gstAmount?.toLocaleString("en-IN")}</span>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={handleSave}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-linear-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-extrabold text-sm uppercase shadow-md transition-all hover:-translate-y-0.5"
        >
          <Save className="w-4 h-4" />
          {t("savePrint")}
        </button>
        <button
          onClick={handlePreview}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-extrabold text-sm uppercase transition-all"
        >
          <Eye className="w-4 h-4" />
          {t("previewBtn")}
        </button>
        <button
          onClick={handleReset}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-extrabold text-sm uppercase transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          {t("resetBtn")}
        </button>
      </div>
    </div>
  );
};
