import React from "react";
import { Palette, RotateCw, Cloud, CheckCircle2, ShieldAlert, AlertCircle } from "lucide-react";
import { PriceSettings } from "../types";

interface HeaderProps {
  lang: "bn" | "en";
  setLang: (lang: "bn" | "en") => void;
  prices: PriceSettings;
  fetchPrices: () => void;
  syncState: "idle" | "saving" | "saved" | "error";
  randomizeTheme: () => void;
  t: (key: string) => string;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  setLang,
  prices,
  fetchPrices,
  syncState,
  randomizeTheme,
  t,
}) => {
  const [tickerOffset, setTickerOffset] = React.useState(0);
  const today = new Date().toLocaleDateString(lang === "en" ? "en-IN" : "bn-BD", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const getSyncIcon = () => {
    switch (syncState) {
      case "saving":
        return <RotateCw className="w-5 h-5 text-amber-500 animate-spin" />;
      case "saved":
        return <CheckCircle2 className="w-5 h-5 text-emerald-500 animate-bounce" />;
      case "error":
        return <ShieldAlert className="w-5 h-5 text-red-500 animate-pulse" />;
      default:
        return <Cloud className="w-5 h-5 text-sky-400" />;
    }
  };

  const getSyncTitle = () => {
    switch (syncState) {
      case "saving":
        return t("syncSaving");
      case "saved":
        return t("syncSaved");
      case "error":
        return t("syncError");
      default:
        return t("syncIdle");
    }
  };

  // Convert 24k base to displayable locale rates
  const formatted24ct = prices.goldPrice > 0 
    ? `₹${prices.goldPrice.toLocaleString("en-IN")}` 
    : "--";
  const formatted22ct = prices.goldPrice > 0 
    ? `₹${Math.floor(prices.goldPrice * 0.92).toLocaleString("en-IN")}` 
    : "--";

  const tickerText = t("tickerAd")
    .replace("{p24}", formatted24ct)
    .replace("{p22}", formatted22ct);

  return (
    <header className="relative w-full overflow-hidden transition-all duration-500 bg-linear-to-r from-sky-500 to-sky-700 dark:from-slate-800 dark:to-slate-950 border-b-4 border-sky-800 shadow-xl max-w-7xl mx-auto rounded-b-2xl mt-1">
      {/* Dynamic Background Mesh Grid */}
      <div className="absolute inset-0 opacity-15 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-200 via-sky-300 to-indigo-500 pointer-events-none" />

      <div className="relative px-6 py-5 flex flex-col md:flex-row justify-between items-center gap-4 z-10">
        {/* Brand Logotype */}
        <div className="flex items-center gap-4">
          <div className="relative group">
            <div className="absolute -inset-1 bg-linear-to-r from-amber-400 to-rose-500 rounded-full blur-sm opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" />
            <div className="relative w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg bg-sky-100 flex items-center justify-center">
              {/* Inline fallbacks if Logo.jpg doesn't exist */}
              <img
                src="/Logo.jpg"
                alt="Soleman Logo"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NSIgaGVpZ2h0PSI2NSI+PGNpcmNsZSBjeD0iMzIuNSIgY3k9IjMyLjUiIHI9IjI1IiBmaWxsPSIjMDJhNGM3Ii8+PHRleHQgeD0iMzIiIHk9IjM3IiBmaWxsPSIjZmZmIiBmb250LWZhbWlseT0ic2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNiIgZm9udC13ZWlnaHQ9ImJvbGQiIHRleHQtYW5jaG9yPSJtaWRkbGUiPlNKPC90ZXh0Pjwvc3ZnPg==";
                }}
              />
            </div>
          </div>
          <div className="text-white">
            <h1 className="text-3xl font-extrabold tracking-tight drop-shadow-md">
              {t("shopName")} <span className="text-amber-300">™</span>
            </h1>
            <p className="text-xs text-sky-100/80 uppercase font-bold tracking-widest mt-0.5">
              Certified Hallmark jewellery point
            </p>
          </div>
        </div>

        {/* Right Side Controls & Spot Rates */}
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto justify-end">
          {/* Quick Toolbar */}
          <div className="flex items-center gap-3">
            {/* Color Palette randomizer */}
            <button
              onClick={randomizeTheme}
              className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all duration-300 ring-1 ring-white/20 shadow-xs hover:scale-105 active:scale-95"
              title={t("changeTheme")}
            >
              <Palette className="w-5 h-5" />
            </button>

            {/* Language switch toggle */}
            <div className="flex bg-white/10 p-0.5 rounded-full ring-1 ring-white/20">
              <button
                onClick={() => setLang("bn")}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  lang === "bn"
                    ? "bg-white text-sky-700 shadow-xs"
                    : "text-white hover:text-white/80"
                }`}
              >
                বাংলা
              </button>
              <button
                onClick={() => setLang("en")}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                  lang === "en"
                    ? "bg-white text-sky-700 shadow-xs"
                    : "text-white hover:text-white/80"
                }`}
              >
                EN
              </button>
            </div>

            {/* Secure Sync badge */}
            <div
              className={`p-2.5 rounded-full hover:bg-white/10 transition-all cursor-help relative group`}
              title={getSyncTitle()}
            >
              {getSyncIcon()}
              {/* Tooltip content floating */}
              <div className="hidden group-hover:block absolute top-12 left-1/2 -translate-x-1/2 px-2.5 py-1 bg-slate-800 text-white text-[10px] uppercase font-bold tracking-wider rounded-lg shadow-xl whitespace-nowrap z-50">
                {getSyncTitle()}
              </div>
            </div>
          </div>

          {/* Active spot rates card block */}
          <div className="flex flex-col bg-white/10 dark:bg-black/30 text-white border border-white/10 dark:border-white/5 rounded-xl px-4 py-2 text-xs min-w-44 shadow-lg leading-relaxed relative overflow-hidden ring-1 ring-white/5">
            <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest block text-center mb-1">
              {today}
            </span>
            <div className="flex justify-between items-center gap-4">
              <span>{t("c24")}</span>
              <strong className="text-sm text-yellow-300 font-mono drop-shadow-sm font-bold">
                {formatted24ct}
              </strong>
            </div>
            <div className="flex justify-between items-center gap-4 mt-0.5">
              <span>{t("c22")}</span>
              <strong className="text-sm text-yellow-300 font-mono drop-shadow-sm font-bold">
                {formatted22ct}
              </strong>
            </div>

            <button
              onClick={fetchPrices}
              className="mt-2 w-full flex items-center justify-center gap-1 bg-white/10 hover:bg-white/20 border border-white/10 text-white rounded-md py-1 font-bold text-[10px] text-center uppercase tracking-wider transition-all cursor-pointer hover:shadow-xs active:scale-95"
            >
              <RotateCw className="w-3 h-3 text-sky-300" />
              {t("livePriceBtn")}
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Ad / Prices Slider Ticker */}
      <div className="w-full bg-sky-900/65 dark:bg-black/50 border-t border-sky-800/80 dark:border-white/5 py-1.5 overflow-hidden text-center select-none relative z-10">
        <div className="inline-block whitespace-nowrap animate-marquee">
          <span className="text-xs font-semibold px-4 text-sky-100 hover:text-white transition-colors duration-300 gap-2 font-sans tracking-wide">
            {tickerText}
          </span>
        </div>
      </div>

      {/* Tailwind marquee keyframe custom inject style */}
      <style>{`
        @keyframes marquee {
          0% { transform: translate3d(100%, 0, 0); }
          100% { transform: translate3d(-100%, 0, 0); }
        }
        .animate-marquee {
          padding-left: 100%;
          animation: marquee 30s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
    </header>
  );
};
