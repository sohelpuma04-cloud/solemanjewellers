import React from "react";
import { X, Printer, ShieldAlert, BadgeCheck, FileText } from "lucide-react";
import { BillItem, LoanAccount, ExchangeBillDetails } from "../types";
import { formatGramsToVoriAnaKuch } from "../utils/calculations";

interface InvoiceModalProps {
  lang: "bn" | "en";
  activeItem: BillItem | { account: LoanAccount; calc: any } | null;
  onClose: () => void;
  t: (key: string) => string;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  lang,
  activeItem,
  onClose,
  t,
}) => {
  if (!activeItem) return null;

  const handlePrint = () => {
    window.print();
  };

  const isLoanAccount = "account" in activeItem;

  // Invoice header metadata calculations
  let invoiceId = "";
  let customerName = "N/A";
  let customerPhone = "N/A";
  let dateStr = "";

  if (isLoanAccount) {
    const act = activeItem.account;
    invoiceId = `GL-${act.id.toString().slice(-6)}`;
    customerName = act.name;
    customerPhone = act.mobile || "N/A";
    dateStr = new Date(act.lastUpdated).toLocaleDateString(lang === "en" ? "en-IN" : "bn-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } else {
    const bl = activeItem as BillItem;
    invoiceId = `SJ-${bl.id.toString().slice(-6)}`;
    customerName = bl.customerName || "N/A";
    customerPhone = "customerPhone" in bl ? bl.customerPhone : ("customerMobile" in bl ? bl.customerMobile : "N/A");
    dateStr = new Date(bl.date).toLocaleDateString(lang === "en" ? "en-IN" : "bn-BD", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  }

  const renderBillContent = () => {
    if (isLoanAccount) {
      const { account, calc } = activeItem as { account: LoanAccount; calc: any };
      return (
        <div className="space-y-6">
          <div className="text-center font-bold text-slate-800 dark:text-slate-100 uppercase tracking-widest border-b pb-2 text-sm border-dashed">
            {t("loanBill")}
          </div>
          
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900 border-b font-black text-slate-500">
                <th className="p-2">{t("dateStr")}</th>
                <th className="p-2">{t("desc")}</th>
                <th className="p-2 text-right">{t("qty")}</th>
              </tr>
            </thead>
            <tbody className="font-semibold text-slate-700 dark:text-slate-300">
              {account.transactions.map((tr) => (
                <tr key={tr.id} className="border-b border-dashed border-slate-100 dark:border-slate-800">
                  <td className="p-2 font-mono">{new Date(tr.date).toLocaleDateString("en-GB")}</td>
                  <td className="p-2 uppercase tracking-wide">
                    {tr.type === "borrow" ? t("transGiveLabel") : t("transTakeLabel")}
                  </td>
                  <td className={`p-2 text-right font-mono font-bold ${tr.type === "borrow" ? "text-rose-600" : "text-emerald-600"}`}>
                    ₹{tr.amount.toLocaleString("en-IN")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* loan amortized summary metrics */}
          <div className="pt-2 space-y-2 border-t border-slate-200/60 dark:border-slate-800 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500 font-bold">{t("totalDur")}:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">{calc.durationText}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 font-bold">{t("currPrin")}:</span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-200">₹{calc.finalPrincipal.toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 font-bold">
                {t("totInt")} ({account.interestType === "percent" ? `${account.interestRate}% monthly` : `Fixed ₹${account.interestRate} monthly`}):
              </span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-200">₹{calc.totalInterest.toLocaleString("en-IN")}</span>
            </div>
            {calc.discountAmount > 0 && (
              <div className="flex justify-between text-rose-500">
                <span className="font-bold">{t("discount")}:</span>
                <span className="font-mono font-bold">-₹{calc.discountAmount.toLocaleString("en-IN")}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-slate-500 font-bold">{t("grandTot")}:</span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-200">₹{calc.grandTotal.toLocaleString("en-IN")}</span>
            </div>
            {calc.finalPayable !== calc.grandTotal && (
              <div className="flex justify-between text-rose-600">
                <span className="font-bold">{t("advGiven")}:</span>
                <span className="font-mono font-bold">-₹{(calc.grandTotal - calc.finalPayable).toLocaleString("en-IN")}</span>
              </div>
            )}
            <div className="flex justify-between pt-2 border-t text-sm font-black bg-emerald-500/5 px-2 py-1.5 rounded-lg border-emerald-500/10">
              <span className="text-emerald-700 dark:text-emerald-400">{t("custPay")}:</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400 text-base">₹{calc.finalPayable.toLocaleString("en-IN")}</span>
            </div>
          </div>
        </div>
      );
    }

    const bill = activeItem as BillItem;

    if (bill.billType === "profit") {
      let makingDisplay = "";
      if (bill.makingChargeType === "pergram") makingDisplay = `@ ₹${bill.makingChargeValue}/g`;
      else if (bill.makingChargeType === "percent") makingDisplay = `@ ${bill.makingChargeValue}%`;
      else makingDisplay = `@ Flat ₹${bill.makingChargeValue}`;

      return (
        <div className="space-y-4 text-xs font-semibold">
          <div className="text-center font-bold text-slate-800 dark:text-slate-100 uppercase tracking-widest border-b pb-2 text-sm border-dashed">
            {t("salesBill")}
          </div>
          <div className="grid grid-cols-2 gap-2 text-slate-600 dark:text-slate-400 border-b pb-3 mb-2">
            <div><span className="text-slate-400 font-bold block">{t("goldQual")}</span>{bill.qualityName}</div>
            <div><span className="text-slate-400 font-bold block">{t("weightLabel")}</span>{bill.weightGrams} {t("gram")}</div>
            <div className="col-span-2 text-[10px] italic text-emerald-600 font-medium">
              {formatGramsToVoriAnaKuch(bill.weightGrams, lang)}
            </div>
          </div>

          <div className="space-y-2.5">
            <div className="flex justify-between border-b border-dashed border-slate-100 dark:border-slate-800 pb-1.5">
              <span>{t("goldValue")}:</span>
              <span className="font-mono">₹{bill.totalGoldValue.toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between border-b border-dashed border-slate-100 dark:border-slate-800 pb-1.5">
              <span>{t("makingLabel")} ({makingDisplay}):</span>
              <span className="font-mono">₹{bill.totalMakingCharge.toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between border-b border-dashed border-slate-100 dark:border-slate-800 pb-1.5">
              <span>{t("subtotal")}:</span>
              <span className="font-mono">₹{(bill.totalGoldValue + bill.totalMakingCharge).toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between pb-1">
              <span>{t("gst")} ({bill.gstPercent}%):</span>
              <span className="font-mono">₹{bill.gstAmount.toLocaleString("en-IN")}</span>
            </div>
            <div className="flex justify-between pt-2.5 border-t text-sm font-black bg-sky-500/5 px-2 py-2 rounded-lg border-sky-500/10">
              <span className="text-sky-700 dark:text-sky-400">{t("totalPriceGST")}:</span>
              <span className="font-mono text-sky-600 dark:text-sky-400 text-base">₹{bill.total.toLocaleString("en-IN")}</span>
            </div>
          </div>
        </div>
      );
    }

    if (bill.billType === "oldToNew") {
      let makingDisplay = "";
      if (bill.makingType === "pergram") makingDisplay = `@ ₹${bill.makingValue}/g`;
      else if (bill.makingType === "percent") makingDisplay = `@ ${bill.makingValue}%`;
      else makingDisplay = `@ Flat ₹${bill.makingValue}`;

      const isRefunding = bill.deficitWeight < 0;
      const highlightTitle = isRefunding ? t("shopReturn") : t("totalPayable");
      const highlightValue = isRefunding
        ? `₹${(bill.finalRefundable || 0).toLocaleString("en-IN")}`
        : `₹${(bill.totalPayable || 0).toLocaleString("en-IN")}`;

      return (
        <div className="space-y-4 text-xs font-semibold">
          <div className="text-center font-bold text-slate-800 dark:text-slate-100 uppercase tracking-widest border-b pb-2 text-sm border-dashed">
            {t("oldToNewReceipt")}
          </div>

          <table className="w-full text-xs text-left border-collapse mb-4 leading-relaxed">
            <tbody>
              <tr className="border-b"><td className="p-2 font-bold text-rose-500">{t("oldJewelry")}</td><td className="p-2 text-right font-mono font-bold">{bill.oldWeight}g</td></tr>
              <tr className="border-b text-[10px] text-slate-400"><td className="p-2 pl-4">└─ {t("deducted")} Melt / Waste</td><td className="p-2 text-right">-{bill.deductionInGrams}g</td></tr>
              <tr className="border-b font-extrabold text-emerald-600"><td className="p-2 pl-4">└─ {t("pureGoldRec")} Settle</td><td className="p-2 text-right">{bill.pureGoldEq}g</td></tr>
              <tr className="border-b"><td className="p-2 font-bold text-sky-500">{t("newJewelry")}</td><td className="p-2 text-right font-mono font-bold">{bill.newWeight}g</td></tr>
            </tbody>
          </table>

          <div className="space-y-2 border-t pt-2 max-w-full overflow-hidden">
            {bill.deficitWeight > 0 ? (
              <>
                <div className="flex justify-between border-b border-dashed pb-1.5">
                  <span>{t("extraGoldNeeded")} ({bill.deficitWeight}g):</span>
                  <span className="font-mono">₹{bill.costOfDeficitGold?.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between border-b border-dashed pb-1.5">
                  <span>{t("totMaking")} ({makingDisplay}):</span>
                  <span className="font-mono">₹{bill.totalMakingCharge.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between border-b border-dashed pb-1.5">
                  <span>{t("subtotal")}:</span>
                  <span className="font-mono">₹{bill.subtotal?.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between pb-1">
                  <span>{t("gst")} ({bill.gstPercent}%):</span>
                  <span className="font-mono">₹{bill.gstAmount?.toLocaleString("en-IN")}</span>
                </div>
              </>
            ) : (
              <>
                <div className="flex justify-between border-b border-dashed pb-1.5">
                  <span>Gold Alloy Refund Surplus ({Math.abs(bill.deficitWeight).toFixed(3)}g):</span>
                  <span className="font-mono text-emerald-600">₹{bill.creditValue?.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between pb-1.5 border-b border-dashed">
                  <span>{t("totMaking")} ({makingDisplay}):</span>
                  <span className="font-mono">₹{bill.totalMakingCharge.toLocaleString("en-IN")}</span>
                </div>
              </>
            )}
            <div className="flex justify-between pt-2.5 border-t text-sm font-black bg-emerald-500/5 px-2 py-2 rounded-lg border-emerald-500/10">
              <span className="text-emerald-700 dark:text-emerald-400">{highlightTitle}:</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400 text-base">{highlightValue}</span>
            </div>
          </div>
        </div>
      );
    }

    // Exchange and Silver Exchange
    const blEx = bill as ExchangeBillDetails;
    let makingExDisplay = "";
    if (blEx.labourType === "pergram") makingExDisplay = `@ ₹${blEx.labourValue}/g`;
    else if (blEx.labourType === "percent") makingExDisplay = `@ ${blEx.labourValue}%`;
    else makingExDisplay = `@ Flat ₹${blEx.labourValue}`;

    const isRefundingEx = blEx.balance < -0.005;
    const highlightExTitle = isRefundingEx ? t("shopReturn") : t("custPay");
    const highlightExValue = isRefundingEx
      ? `₹${Math.abs(blEx.balance).toLocaleString("en-IN")}`
      : `₹${blEx.finalPayable.toLocaleString("en-IN")}`;

    const titleBanner = blEx.billType === "silverExchange" ? t("silverExTitle") : t("goldExTitle");

    return (
      <div className="space-y-4 text-xs font-semibold">
        <div className="text-center font-bold text-slate-800 dark:text-slate-100 uppercase tracking-widest border-b pb-2 text-sm border-dashed">
          {titleBanner} Invoice
        </div>

        <table className="w-full text-xs text-left border-collapse border border-slate-100 dark:border-slate-850 rounded-lg overflow-hidden leading-relaxed">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-900 border-b">
              <th className="p-2 font-bold">{t("detailsLabel")}</th>
              <th className="p-2 text-right font-bold">{t("totalLabel")}</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b font-black bg-slate-50/50 dark:bg-slate-900/30"><td colSpan={2} className="p-2 text-sky-600">{t("newJewelry")}</td></tr>
            <tr className="border-b"><td className="p-2 font-medium pl-4">Spot Value ({blEx.newWeight.toFixed(3)}g)</td><td className="p-2 text-right font-mono">₹{blEx.baseNewValue.toLocaleString("en-IN")}</td></tr>
            <tr className="border-b border-dashed"><td className="p-2 font-medium pl-4">Making Surcharge ({makingExDisplay})</td><td className="p-2 text-right font-mono">₹{blEx.labourAmount.toLocaleString("en-IN")}</td></tr>
            <tr className="border-b"><td className="p-2 font-bold pl-4">Gross Asset Cost</td><td className="p-2 text-right font-mono font-bold">₹{blEx.newGross.toLocaleString("en-IN")}</td></tr>
            
            <tr className="border-b font-black bg-slate-50/50 dark:bg-slate-900/30"><td colSpan={2} className="p-2 text-rose-600">{t("oldJewelry")}</td></tr>
            <tr className="border-b"><td className="p-2 font-medium pl-4">Melt Trade-In ({blEx.oldWeight.toFixed(3)}g at {blEx.purity}%)</td><td className="p-2 text-right font-mono">₹{blEx.oldNet.toLocaleString("en-IN")}</td></tr>
          </tbody>
        </table>

        {/* balance specs */}
        <div className="space-y-2 border-t pt-2">
          <div className="flex justify-between border-b border-dashed pb-1.5">
            <span>{t("balance")}:</span>
            <span className="font-mono">₹{blEx.balance.toLocaleString("en-IN")}</span>
          </div>
          {blEx.includeGst && blEx.balance > 0 && (
            <div className="flex justify-between pb-1 border-b border-dashed">
              <span>{t("gst")} ({blEx.gstPercent}%):</span>
              <span className="font-mono">₹{blEx.gstOnPayable.toLocaleString("en-IN")}</span>
            </div>
          )}
          <div className="flex justify-between pt-2.5 border-t text-sm font-black bg-emerald-500/5 px-2 py-2 rounded-lg border-emerald-500/10">
            <span className="text-emerald-700 dark:text-emerald-400">{highlightExTitle}:</span>
            <span className="font-mono text-emerald-600 dark:text-emerald-400 text-base">{highlightExValue}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-[2000] flex justify-center items-center py-6 px-4 overflow-y-auto block printing-overlay animate-fadeIn">
      {/* Container invoice card */}
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-2xl relative flex flex-col max-h-[90vh] overflow-hidden printing-container animate-scaleIn">
        {/* Absolute header buttons */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800/80 mb-4 flex-shrink-0">
          <span className="text-xs font-black text-slate-450 uppercase flex items-center gap-1 font-mono tracking-wider">
            <FileText className="w-4 h-4 text-sky-500" />
            Serial: {invoiceId}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 hover:scale-105 text-slate-850 dark:text-white rounded-lg flex items-center gap-1 font-bold text-[10px] uppercase tracking-wider transition duration-300 pointer"
            >
              <Printer className="w-4 h-4 text-sky-500 animate-pulse" />
              {lang === "en" ? "System Print" : "প্রিন্ট"}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-rose-500/10 hover:text-rose-600 text-slate-400 rounded-lg cursor-pointer transition duration-300"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Modal interactive document wrapper */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-6 printable-region pb-16 font-sans">
          {/* Shop branding address banner */}
          <div className="text-center space-y-1">
            <h2 className="text-2xl font-black text-sky-600 dark:text-sky-400 tracking-tight leading-none uppercase">
              {t("shopNamePrint")}
            </h2>
            <p className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest">{t("footerAddr")}</p>
            <p className="text-[9px] font-bold text-slate-400 tracking-wider">
              GSTIN: 19BMZPR4273E1Z9 | BIS Licence: HM/C-5191720314
            </p>
          </div>

          {/* Customer & Document details info block */}
          <div className="grid grid-cols-2 gap-3 text-[10px] bg-slate-50 dark:bg-slate-950/60 p-3 rounded-2xl border border-slate-100 dark:border-slate-850/50 leading-relaxed font-semibold">
            <div>
              <span className="text-slate-400 font-bold block uppercase tracking-wider">{t("custName")}</span>
              <span className="text-slate-800 dark:text-slate-200 text-xs font-extrabold block mt-0.5">{customerName}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 font-bold block uppercase tracking-wider">{t("issueDate")}</span>
              <span className="text-slate-855 text-xs font-bold block mt-0.5">{dateStr}</span>
            </div>
            <div className="mt-1">
              <span className="text-slate-400 font-bold block uppercase tracking-wider">{t("phone")}</span>
              <span className="text-slate-800 dark:text-slate-200 font-mono block mt-0.5">{customerPhone}</span>
            </div>
            <div className="text-right mt-1">
              <span className="text-slate-400 font-bold block uppercase tracking-wider">Registration Status</span>
              <span className="inline-flex items-center gap-0.5 text-xs font-black text-emerald-600 mt-0.5 font-mono">
                <BadgeCheck className="w-3.5 h-3.5" />
                VERIFIED
              </span>
            </div>
          </div>

          {/* Calculation details tables output */}
          <div className="border border-slate-100 dark:border-slate-800 rounded-2xl p-4 bg-white dark:bg-slate-900/10">
            {renderBillContent()}
          </div>

          {/* Settle declaration & Signature parameters */}
          <div className="flex justify-between items-end pt-12 border-t border-slate-200/50 dark:border-slate-800/80 border-dashed text-[10px] text-slate-400">
            <div className="space-y-1">
              <span className="font-extrabold block text-slate-500 uppercase tracking-widest">Legal Notice</span>
              <p className="max-w-[190px] leading-tight text-[8px] font-semibold italic text-slate-400">
                This is a computer compiled invoice document issued on behalf of Soleman Jewellers. Subject to Bhaduriapara jurisdictions.
              </p>
            </div>
            <div className="text-center font-bold">
              <div className="w-32 border-b border-slate-300 dark:border-slate-700 border-dashed mb-1.5" />
              <span className="uppercase tracking-widest text-[9px] font-black block">{t("signature")}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Embedded specific print css media queries to assure print frames hide buttons and match pages */}
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          .printing-overlay, .printing-overlay * {
            visibility: visible !important;
          }
          .printing-overlay {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            height: auto !important;
            background: white !important;
            padding: 0 !important;
            margin: 0 !important;
            z-index: 99999 !important;
          }
          .printing-container {
            border: none !important;
            box-shadow: none !important;
            max-height: none !important;
            overflow: visible !important;
            padding: 10px !important;
            width: 100% !important;
            max-width: 100% !important;
          }
          .printable-region {
            overflow: visible !important;
            padding-bottom: 0 !important;
          }
          ul, button, select, input, label[for^="taxRequiredEx"] {
            display: none !important;
          }
          button {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
};
