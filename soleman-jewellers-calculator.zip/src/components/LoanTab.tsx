import React from "react";
import { Banknote, ListPlus, Calendar, Plus, RefreshCw, Coins, Trash2, UserCheck, Eye, Save, ChevronDown, ChevronUp, AlertCircle } from "lucide-react";
import { LoanTransaction, LoanAccount } from "../types";
import { calculateLoanInterest } from "../utils/calculations";

interface LoanTabProps {
  lang: "bn" | "en";
  savedAccounts: LoanAccount[];
  onSaveAccount: (account: Omit<LoanAccount, "lastUpdated">) => void;
  onDeleteAccount: (id: number) => void;
  onPrintLoanBill: (account: LoanAccount, calc: any) => void;
  t: (key: string) => string;
}

export const LoanTab: React.FC<LoanTabProps> = ({
  lang,
  savedAccounts,
  onSaveAccount,
  onDeleteAccount,
  onPrintLoanBill,
  t,
}) => {
  // Customer Details
  const [currentAccountId, setCurrentAccountId] = React.useState<number | null>(null);
  const [customerName, setCustomerName] = React.useState("");
  const [mobile, setMobile] = React.useState("");

  // Interest Rule Setup
  const [interestType, setInterestType] = React.useState<"percent" | "fixed">("percent");
  const [interestRate, setInterestRate] = React.useState<number>(3);

  // New Transaction Builder
  const [transDate, setTransDate] = React.useState(new Date().toISOString().split("T")[0]);
  const [amount, setAmount] = React.useState<number>(0);
  const [type, setType] = React.useState<"borrow" | "repay">("borrow");

  // Active Ledger transactions
  const [transactions, setTransactions] = React.useState<LoanTransaction[]>([]);

  // Calculation parameters
  const [calcDate, setCalcDate] = React.useState(new Date().toISOString().split("T")[0]);
  const [advance, setAdvance] = React.useState<number>(0);

  const [showFullCalc, setShowFullCalc] = React.useState(false);

  // Auto-fill active calculations outcomes
  const calcResult = calculateLoanInterest(transactions, calcDate, interestType, interestRate, advance, lang);

  const handleAddTransaction = () => {
    if (!transDate || amount <= 0) {
      alert(t("toastNeedCalc"));
      return;
    }
    const newTrans: LoanTransaction = {
      id: Date.now(),
      date: transDate,
      amount,
      type,
    };
    const updated = [...transactions, newTrans].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    setTransactions(updated);
    setAmount(0);
  };

  const handleDeleteTransaction = (id: number) => {
    if (confirm(t("confirmDel"))) {
      setTransactions(transactions.filter((tr) => tr.id !== id));
    }
  };

  const handleCreateOrUpdateAccount = () => {
    if (!customerName.trim()) {
      alert(t("toastNeedName"));
      return;
    }
    if (transactions.length === 0) {
      alert(t("noTrans"));
      return;
    }
    const accId = currentAccountId || Date.now();
    onSaveAccount({
      id: accId,
      name: customerName.trim(),
      mobile: mobile.trim(),
      interestType,
      interestRate,
      transactions,
    });
    setCurrentAccountId(accId);
  };

  const handleLoadAccount = (acc: LoanAccount) => {
    setCurrentAccountId(acc.id);
    setCustomerName(acc.name);
    setMobile(acc.mobile);
    setInterestType(acc.interestType);
    setInterestRate(acc.interestRate);
    setTransactions(acc.transactions);
  };

  const handleReset = () => {
    if (transactions.length > 0 && confirm(t("confirmReset"))) {
      setTransactions([]);
      setCurrentAccountId(null);
      setCustomerName("");
      setMobile("");
      setInterestType("percent");
      setInterestRate(3);
      setAdvance(0);
      setAmount(0);
      setShowFullCalc(false);
    }
  };

  const handlePrint = () => {
    if (transactions.length === 0 || !calcResult) {
      alert(t("toastNeedCalc"));
      return;
    }
    handleCreateOrUpdateAccount();
    const mockAccount: LoanAccount = {
      id: currentAccountId || Date.now(),
      name: customerName.trim() || t("custName"),
      mobile: mobile.trim() || "--",
      interestType,
      interestRate,
      transactions,
      lastUpdated: new Date().toISOString(),
    };
    onPrintLoanBill(mockAccount, calcResult);
  };

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-slate-200/50 dark:border-slate-800/80 max-w-3xl mx-auto space-y-6">
      {/* Title block */}
      <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div className="p-2 rounded-lg bg-sky-500/10 text-sky-600 dark:text-sky-400">
          <Banknote className="w-6 h-6" />
        </div>
        <h3 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 uppercase tracking-wide">
          {t("loanTitle")}
        </h3>
      </div>

      {/* Customer details info */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4">
        <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
          {t("custInfo")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("custName")}</label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder={t("enterName")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("phone")}</label>
            <input
              type="tel"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              placeholder={t("enterPhone")}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-medium text-slate-800 dark:text-slate-200 focus:focus:ring-2 focus:ring-sky-500/50 focus:bg-white text-sm"
            />
          </div>
        </div>
      </fieldset>

      {/* Amortization parameters settings */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4">
        <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
          {t("intRateTitle")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("loanType")}</label>
            <select
              value={interestType}
              onChange={(e) => setInterestType(e.target.value as any)}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 text-sm cursor-pointer"
            >
              <option value="percent">{t("monthlyPct")}</option>
              <option value="fixed">{t("fixedAmt")}</option>
            </select>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">
              {interestType === "percent" ? t("intRate") : t("fixedAmt") + " (₹)"}
            </label>
            <input
              type="number"
              step="0.01"
              value={interestRate || ""}
              onChange={(e) => setInterestRate(Math.max(0, parseFloat(e.target.value) || 0))}
              className="lg:p-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 font-bold text-slate-850 text-sm font-mono"
            />
          </div>
        </div>
      </fieldset>

      {/* ledger items builder */}
      <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 grid grid-cols-1 gap-4">
        <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
          {t("addTrans")}
        </legend>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-sky-500" />
              {t("date")}
            </label>
            <input
              type="date"
              value={transDate}
              onChange={(e) => setTransDate(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 font-semibold text-xs"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-amber-500" />
              {t("amount")} (₹)
            </label>
            <input
              type="number"
              value={amount || ""}
              onChange={(e) => setAmount(Math.max(0, parseInt(e.target.value) || 0))}
              placeholder="0"
              className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 font-mono text-xs font-bold"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400">{t("transType")}</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as any)}
              className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 text-xs font-semibold cursor-pointer"
            >
              <option value="borrow" className="text-rose-600 font-bold">
                {t("giveLoan")}
              </option>
              <option value="repay" className="text-emerald-600 font-bold">
                {t("takeRepay")}
              </option>
            </select>
          </div>
        </div>
        <button
          onClick={handleAddTransaction}
          className="mt-2 w-full sm:w-auto self-start flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs uppercase"
        >
          <Plus className="w-4 h-4" />
          {t("addToList")}
        </button>
      </fieldset>

      {/* Ledger lists Table */}
      <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-950/40">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 border-dashed text-slate-500 font-bold uppercase tracking-wider">
                <th className="p-3.5">{t("date")}</th>
                <th className="p-3.5">{t("desc")}</th>
                <th className="p-3.5 text-right">{t("amount")}</th>
                <th className="p-3.5 text-right w-12">{t("del")}</th>
              </tr>
            </thead>
            <tbody className="font-semibold text-slate-700 dark:text-slate-300">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-slate-400 italic font-medium">
                    {t("noTrans")}
                  </td>
                </tr>
              ) : (
                transactions.map((tr) => {
                  const isBorrow = tr.type === "borrow";
                  return (
                    <tr
                      key={tr.id}
                      className="border-b border-slate-100 dark:border-slate-900 hover:bg-slate-100/50 dark:hover:bg-slate-950/50 transition-colors"
                    >
                      <td className="p-3.5 font-mono">{new Date(tr.date).toLocaleDateString("en-GB")}</td>
                      <td className="p-3.5">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-sm text-[10px] font-black uppercase tracking-wider ${
                            isBorrow
                              ? "bg-rose-500/10 text-rose-600 dark:text-rose-400"
                              : "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                          }`}
                        >
                          {isBorrow ? t("transGiveLabel") : t("transTakeLabel")}
                        </span>
                      </td>
                      <td
                        className={`p-3.5 text-right font-mono font-bold text-sm ${
                          isBorrow ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"
                        }`}
                      >
                        ₹{tr.amount.toLocaleString("en-IN")}
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => handleDeleteTransaction(tr.id)}
                          className="p-1 text-slate-450 hover:text-rose-600 cursor-pointer rounded-full transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Statement parameters */}
      {transactions.length > 0 && (
        <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono">
            {t("intPrinCalc")}
          </legend>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-sky-500" />
              {t("endDate")}
            </label>
            <input
              type="date"
              value={calcDate}
              onChange={(e) => setCalcDate(e.target.value)}
              className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 font-bold text-xs"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-sky-500" />
              {t("advGiven")} (₹)
            </label>
            <input
              type="number"
              value={advance || ""}
              onChange={(e) => setAdvance(Math.max(0, parseInt(e.target.value) || 0))}
              placeholder="0"
              className="p-2.5 rounded-lg border border-slate-200 bg-slate-50 font-mono text-xs font-bold"
            />
          </div>
        </fieldset>
      )}

      {/* Calculations summaries */}
      {transactions.length > 0 && calcResult && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* duration */}
          <div className="p-4 rounded-xl border border-purple-500/10 bg-purple-500/5 text-center shadow-xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              {t("totalDur")}
            </span>
            <strong className="text-base text-slate-800 dark:text-slate-100 font-bold">{calcResult.durationText}</strong>
          </div>
          {/* principal */}
          <div className="p-4 rounded-xl border border-blue-500/10 bg-blue-500/5 text-center shadow-xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              {t("currPrin")}
            </span>
            <strong className="text-base text-slate-800 dark:text-slate-100 font-mono font-bold">
              ₹{calcResult.finalPrincipal.toLocaleString("en-IN")}
            </strong>
          </div>
          {/* Interest */}
          <div className="p-4 rounded-xl border border-rose-500/10 bg-rose-500/5 text-center shadow-xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              {t("totInt")}
            </span>
            <strong className="text-base text-slate-850 font-mono font-bold">
              ₹{calcResult.totalInterest.toLocaleString("en-IN")}
            </strong>
          </div>
          {/* Discount if interest was waived */}
          {calcResult.discountAmount > 0 && (
            <div className="p-4 rounded-xl border border-rose-500/10 bg-rose-500/5 text-center shadow-xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                {t("discount")}
              </span>
              <strong className="text-base text-rose-500 font-mono font-bold">
                -₹{calcResult.discountAmount.toLocaleString("en-IN")}
              </strong>
            </div>
          )}

          {/* Grand total repayment liability */}
          <div className="sm:col-span-2 p-5 rounded-xl bg-linear-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 text-center shadow-xs leading-relaxed">
            <span className="text-xs font-bold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider block mb-1.5">
              {advance > 0 ? t("custPay") : t("grandTot")}
            </span>
            <strong className="text-3xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
              ₹{calcResult.finalPayable.toLocaleString("en-IN")}
            </strong>

            <div className="border-t border-emerald-600/10 mt-4 pt-3 flex flex-col gap-1">
              <button
                onClick={() => setShowFullCalc(!showFullCalc)}
                className="self-center text-[10px] font-black text-emerald-600 hover:text-emerald-700 uppercase tracking-widest flex items-center gap-1 cursor-pointer"
              >
                {t("viewDetails")}
                {showFullCalc ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>

              {showFullCalc && (
                <div className="mt-3 overflow-x-auto text-left rounded-lg border border-emerald-500/10 bg-white/50 dark:bg-black/35">
                  <table className="w-full text-[10px] text-slate-600 dark:text-slate-400">
                    <thead>
                      <tr className="bg-emerald-500/5 border-b border-emerald-500/10 font-bold uppercase uppercase tracking-wider">
                        <th className="p-2">{t("dateTime")}</th>
                        <th className="p-2">{t("prin")}</th>
                        <th className="p-2">{t("dur")}</th>
                        <th className="p-2 text-right">{t("int")}</th>
                      </tr>
                    </thead>
                    <tbody className="font-semibold leading-5 text-slate-700 dark:text-slate-300">
                      {calcResult.breakdown.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="p-4 text-center italic text-slate-400">
                            {t("insufDetails")}
                          </td>
                        </tr>
                      ) : (
                        calcResult.breakdown.map((b, idx) => (
                          <tr key={idx} className="border-b border-slate-100 dark:border-slate-900 border-dashed">
                            <td className="p-2">
                              <div>{b.fromDateStr}</div>
                              <div className="text-[9px] text-slate-400 font-normal">to {b.toDateStr}</div>
                            </td>
                            <td className="p-2 font-mono">₹{b.principal.toLocaleString("en-IN")}</td>
                            <td className="p-2">{b.durationStr}</td>
                            <td className="p-2 text-right text-emerald-600 font-mono font-bold">
                              ₹{b.interest.toLocaleString("en-IN")}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Form interactions controls */}
      <div className="flex flex-wrap gap-3">
        <button
          onClick={handleCreateOrUpdateAccount}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-extrabold text-sm uppercase shadow-md transition-all cursor-pointer"
        >
          <Save className="w-4 h-4" />
          {t("saveOnly")}
        </button>
        <button
          onClick={handlePrint}
          className="flex-1 min-w-40 flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-linear-to-r from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white font-extrabold text-sm uppercase shadow-md transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          {t("printBtn")}
        </button>
        <button
          onClick={handleReset}
          className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-10 border-dashed text-slate-400 hover:text-rose-600 font-extrabold text-sm uppercase transition-all cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" />
          {t("resetBtn")}
        </button>
      </div>

      {/* Saved Accounts section */}
      {savedAccounts.length > 0 && (
        <fieldset className="border border-slate-100 dark:border-slate-800 rounded-xl p-4">
          <legend className="text-xs font-bold text-sky-600 dark:text-sky-400 uppercase tracking-widest px-2 font-mono flex items-center gap-1">
            <UserCheck className="w-4 h-4" />
            Saved Gold Loan Ledgers
          </legend>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
            {savedAccounts.map((acc) => (
              <div
                key={acc.id}
                className={`p-3.5 rounded-xl border flex justify-between items-center transition-all bg-white dark:bg-slate-950/40 ${
                  currentAccountId === acc.id
                    ? "border-sky-500/55 shadow-sky-500/5 bg-sky-500/5"
                    : "border-slate-200/60 dark:border-slate-800/85 hover:border-slate-300 dark:hover:border-slate-700"
                }`}
              >
                <div onClick={() => handleLoadAccount(acc)} className="flex-1 cursor-pointer">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 leading-none mb-1">
                    {acc.name}
                  </h4>
                  <span className="text-[10px] text-slate-400 font-medium block">
                    {acc.mobile || "--"} | {acc.transactions.length} entries
                  </span>
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => handleLoadAccount(acc)}
                    className="p-1.5 hover:bg-sky-500/10 text-sky-600 dark:text-sky-400 rounded-full cursor-pointer transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteAccount(acc.id)}
                    className="p-1.5 hover:bg-rose-500/10 text-rose-600 dark:text-rose-400 rounded-full cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </fieldset>
      )}
    </div>
  );
};
