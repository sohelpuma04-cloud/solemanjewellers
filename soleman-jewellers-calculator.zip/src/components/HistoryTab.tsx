import React from "react";
import { FileText, Calendar, Trash2, Eye, ShieldCheck, Ticket } from "lucide-react";
import { BillItem } from "../types";

interface HistoryTabProps {
  lang: "bn" | "en";
  bills: BillItem[];
  onDeleteBill: (id: number) => void;
  onViewBillDetails: (bill: BillItem) => void;
  t: (key: string) => string;
}

export const HistoryTab: React.FC<HistoryTabProps> = ({
  lang,
  bills,
  onDeleteBill,
  onViewBillDetails,
  t,
}) => {
  const [activeFilter, setActiveFilter] = React.useState<"all" | "profit" | "oldToNew" | "exchange" | "silverExchange">("all");

  const filteredBills = React.useMemo(() => {
    if (activeFilter === "all") return bills;
    return bills.filter((b) => b.billType === activeFilter);
  }, [bills, activeFilter]);

  const getBillIconColor = (type: string) => {
    switch (type) {
      case "profit":
        return "bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/10";
      case "oldToNew":
        return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/10";
      case "exchange":
        return "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/10";
      default:
        return "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/10";
    }
  };

  const getBillTitle = (bill: BillItem) => {
    switch (bill.billType) {
      case "profit":
        return t("tabBS");
      case "oldToNew":
        return t("tabOTN");
      case "exchange":
        return bill.exchangeMode === "nakmachi" ? t("modeNak") : t("tabGoldEx");
      case "silverExchange":
        return t("tabSilverEx");
      default:
        return "Invoice";
    }
  };

  const getBillAmountText = (bill: BillItem) => {
    if (bill.billType === "profit") {
      return `₹${bill.total.toLocaleString("en-IN")}`;
    } else if (bill.billType === "oldToNew") {
      const isRefunding = bill.deficitWeight < 0;
      if (isRefunding) {
        return `Refund: ₹${(bill.finalRefundable || 0).toLocaleString("en-IN")}`;
      } else {
        return `Total: ₹${(bill.totalPayable || 0).toLocaleString("en-IN")}`;
      }
    } else {
      // Exchange and Silver Exchange
      const isRefunding = bill.balance < -0.005;
      if (isRefunding) {
        return `Refund: ₹${Math.abs(bill.balance).toLocaleString("en-IN")}`;
      } else {
        return `Total: ₹${bill.finalPayable.toLocaleString("en-IN")}`;
      }
    }
  };

  return (
    <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-slate-200/50 dark:border-slate-800/80 max-w-3xl mx-auto">
      {/* Page Title */}
      <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4 mb-6">
        <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-600 dark:text-sky-400">
          <FileText className="w-6 h-6" />
        </div>
        <h3 className="text-xl font-extrabold text-slate-800 dark:text-slate-100 uppercase tracking-wide">
          {t("historyTitle")}
        </h3>
      </div>

      {/* Tabs Filter toolbar */}
      <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl mb-6 border border-slate-200/40 dark:border-slate-800/60 shadow-2xs">
        {[
          { id: "all", label: lang === "en" ? "All" : "সব" },
          { id: "profit", label: t("tabBS") },
          { id: "oldToNew", label: t("tabOTN") },
          { id: "exchange", label: t("tabGoldEx") },
          { id: "silverExchange", label: t("tabSilverEx") },
        ].map((filter) => (
          <button
            key={filter.id}
            onClick={() => setActiveFilter(filter.id as any)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition duration-300 cursor-pointer ${
              activeFilter === filter.id
                ? "bg-slate-800 dark:bg-sky-500 text-white shadow-md shadow-slate-800/20"
                : "text-slate-500 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-900"
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Invoices List column */}
      <div className="space-y-4">
        {filteredBills.length === 0 ? (
          <div className="p-12 text-center text-slate-400 italic font-semibold bg-slate-50 dark:bg-slate-950/20 rounded-xl border border-slate-100 dark:border-slate-800 border-dashed">
            {t("noBills")}
          </div>
        ) : (
          filteredBills.map((bill) => {
            const dateStr = new Date(bill.date).toLocaleDateString(lang === "en" ? "en-IN" : "bn-BD", {
              day: "numeric",
              month: "long",
              year: "numeric",
            });
            const cardStyle = getBillIconColor(bill.billType);

            return (
              <div
                key={bill.id}
                className="group relative p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 rounded-xl border border-slate-200/60 dark:border-slate-800/80 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-950/20 hover:scale-[1.01] hover:shadow-lg hover:shadow-slate-500/5 transition duration-300"
              >
                {/* Visual Category ribbon indicator */}
                <div className={`absolute top-0 bottom-0 left-0 w-1.5 rounded-l-xl ${
                  bill.billType === "profit" ? "bg-sky-500" :
                  bill.billType === "oldToNew" ? "bg-emerald-500" :
                  bill.billType === "exchange" ? "bg-amber-500" : "bg-indigo-500"
                }`} />

                <div className="flex-1 pl-3.5">
                  <div className="flex items-center gap-2 flex-wrap mb-1.5">
                    <span
                      className={`px-2 py-0.5 rounded-sm text-[9px] font-black uppercase tracking-wider border ${cardStyle}`}
                    >
                      {getBillTitle(bill)}
                    </span>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold font-mono">
                      SJ-{bill.id.toString().slice(-6)}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-slate-800 dark:text-slate-100 leading-none flex items-center gap-2">
                    {bill.customerName || "N/A / গ্রাহক"}
                  </h4>
                  <div className="text-xs text-slate-450 flex items-center gap-1.5 mt-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{dateStr}</span>
                    {bill.customerPhone && (
                      <span className="font-mono text-[10px] bg-slate-100 dark:bg-slate-950 py-0.5 px-2.5 rounded-lg border border-slate-200/40 select-none">
                        {bill.customerPhone}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex sm:flex-col items-end gap-1.5 sm:gap-2.5 w-full sm:w-auto mt-2 sm:mt-0 justify-between sm:justify-start border-t border-slate-100 sm:border-0 pt-2 sm:pt-0 border-dashed dark:border-slate-800">
                  <span className="text-base font-extrabold text-slate-800 dark:text-slate-100 font-mono">
                    {getBillAmountText(bill)}
                  </span>
                  <div className="flex gap-2.5">
                    <button
                      onClick={() => onViewBillDetails(bill)}
                      className="p-1 px-3 sm:p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center gap-1 font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer hover:shadow-xs active:scale-95"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      {t("viewDetails")}
                    </button>
                    <button
                      onClick={() => onDeleteBill(bill.id)}
                      className="p-1 px-3 sm:p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center gap-1 font-bold text-[10px] uppercase tracking-wider transition-all cursor-pointer hover:shadow-xs active:scale-95"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      {t("del")}
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Security credentials credits banner footer */}
      <footer className="mt-8 border-t border-slate-100 dark:border-slate-800/80 pt-4 flex items-center justify-between text-[10px] uppercase tracking-wider font-extrabold text-slate-400 select-none">
        <span className="flex items-center gap-1 leading-none font-mono">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          Sovereign Backup Sync Secured
        </span>
        <span className="flex items-center gap-1 font-mono">
          <Ticket className="w-3.5 h-3.5 text-sky-500" />
          SJ-AUDIT-LOG v1.2
        </span>
      </footer>
    </div>
  );
};
