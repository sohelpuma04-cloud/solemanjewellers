export interface PriceSettings {
  goldPrice: number;
  oldGoldPriceGeneral: number;
  oldGoldPriceNakmachi: number;
  newSilverPrice: number;
  oldSilverPrice: number;
}

export type BillType = "profit" | "oldToNew" | "exchange" | "silverExchange";

export interface ProfitBillDetails {
  id: number;
  billType: "profit";
  date: string;
  customerName: string;
  customerPhone: string;
  basePrice24ct: number;
  weightGrams: number;
  quality: string;
  qualityName: string;
  makingChargeType: "pergram" | "percent" | "fixed";
  makingChargeValue: number;
  gstPercent: number;
  totalGoldValue: number;
  totalMakingCharge: number;
  gstAmount: number;
  total: number;
}

export interface OldToNewBillDetails {
  id: number;
  billType: "oldToNew";
  date: string;
  customerName: string;
  customerMobile: string;
  oldWeight: number;
  oldType: string;
  newWeight: number;
  newType: string;
  price24ct: number;
  makingType: "pergram" | "percent" | "fixed";
  makingValue: number;
  gstPercent: number;
  pureGoldEq: number;
  deductionInGrams: number;
  deficitWeight: number;
  costOfDeficitGold?: number;
  totalMakingCharge: number;
  subtotal?: number;
  gstAmount?: number;
  totalPayable?: number;
  creditValue?: number;
  excessGoldInGrams?: number;
  finalPayable?: number;
  finalRefundable?: number;
}

export interface ExchangeBillDetails {
  id: number;
  billType: "exchange" | "silverExchange";
  date: string;
  customerName: string;
  customerPhone: string;
  newWeight: number;
  newPrice10g: number;
  labourType: "pergram" | "percent" | "fixed";
  labourValue: number;
  oldWeight: number;
  oldPrice10g: number;
  purity: number;
  gstPercent: number;
  includeGst: boolean;
  baseNewValue: number;
  labourAmount: number;
  newGross: number;
  oldNet: number;
  balance: number;
  gstOnPayable: number;
  finalPayable: number;
  exchangeMode?: "general" | "nakmachi";
}

export type BillItem = ProfitBillDetails | OldToNewBillDetails | ExchangeBillDetails;

export interface LoanTransaction {
  id: number;
  date: string;
  amount: number;
  type: "borrow" | "repay";
}

export interface LoanAccount {
  id: number;
  name: string;
  mobile: string;
  interestType: "percent" | "fixed";
  interestRate: number;
  transactions: LoanTransaction[];
  lastUpdated: string;
}

export interface CloudBackupData {
  bills: string; // JSON Stringified BillItem[]
  loans: string; // JSON Stringified LoanAccount[]
  settings: string; // JSON Stringified PriceSettings
}
